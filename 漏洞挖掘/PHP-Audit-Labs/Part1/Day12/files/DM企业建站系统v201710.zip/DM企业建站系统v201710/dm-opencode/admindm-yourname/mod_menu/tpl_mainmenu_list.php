<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}

?>

 <div class="menu">
     <a href="<?php echo $jumpvadd?>">添加菜单组</a>
 </div>
<?php 
 

	 $sql = "SELECT * from ".TABLE_MENU." where  ppid='0'   $andlangbh  order by pos desc,id";
	 //ECHO $sql;
	 $rowlist = getall($sql);
    if($rowlist == 'no')  echo '<p style="padding:55px;background:#eee">没有菜单，请添加。</p>';
    else {
	?>

<h2 class="h2tit_biao">管理列表</h2> 
<form method=post action="<?php echo $jumpv;?>&act=pos">
<table class="formtab" style="width:100%">
  <tr style="font-weight:bold;background:#eeefff">
  <td width="100" align=center>排序号</td>
    <td width="200">标识</td>
    <td width="300" align=center>菜单组名称</td>
     <td width="200" align=center>管理</td>
    <td width="100" align="center">修改</td>
    <td width="100" align="center">删除</td>
  
  </tr> 
  <?php
      foreach($rowlist as $v){
            $tid = $v['id'];
            $pidname = $v['pidname'];
            $name = $v['name'];
            $sta_cusmenu = $v['sta_cusmenu'];
          
            
 $edit_desp='<a class="but1"   href='.$jumpvedit.'&tid='.$tid.'>修改</a>';

 if($sta_cusmenu=='y')  $gl_desp= '已启动自定义菜单';
 else  $gl_desp='<a class="but3" target="_blank"  href="mod_menu.php?ppid='.$pidname.'&lang='.LANG.'">管理菜单</a>';
          
 $delmenu= " <a class='but2'  href=javascript:del('del','$pidname','$jumpv')>删除</a>";
 if($pidname == $pidmenu)  $delmenu='';

$tr_hide ='';

    ?>
  <tr  <?php echo $tr_hide;?> style="border-top:2px solid #999">
  <td align="center"><input type="text" name="<?php echo $tid;?>"  value="<?php echo $v['pos'];?>" size="5" /></td> 

    <td align="left"><?php echo $pidname;?>
    <?php
      if($pidname == $pidmenu) {echo '<br /><span class="cred">正在使用</span>';}
    ?></td>
    <td align="left"><strong><?php echo $name;?></strong>  </td>
    <td align="center"><?php  echo $gl_desp?></td>
    <td align="center"><?php  echo $edit_desp?></td>
    <td align="center"><?php  echo $delmenu;?></td>
  
     
  </tr>
<?php
    
    } ?>
</table>
<div style="padding-bottom:22px"><input class="mysubmit" type="submit" name="Submit" value="排序" /><?php echo $sort_ads?></div>
</form>
 


<?php 
}
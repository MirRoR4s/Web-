<?php 
 
// $proglang = @htmlentities($_GET['lang']);
// if($proglang=='') $proglang ='cn';
//echo '<p>lang:'.$proglang.'</p>';

//if(LANG=='en') echo  '<a href="../index.html">cn</a>';
//if($proglang=='cn') {echo  '<a href="en/index.html">en</a>   ';}
?>




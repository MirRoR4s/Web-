<?php 
//echo $blockcntid;
$w1text =$w2text = '';


 if($blockcntid=='bkcnt_imgleft'  || $blockcntid=='bkcnt_imgrg'){
     $imgv = '<img class="perimg100" src="'.$imgv.'" alt="'.$name.'" />';


}

 if($blockcntid=='bkcnt_videoleft'  || $blockcntid=='bkcnt_videorg'){

     $imgv  = $stylev ='';

     $imgv.='<div class="videodetail">';

      $videoext = substr($videoaddress, -3);

       if($videoext=='mp4'){
            $stylev = 'style="height:auto"';
            $imgv.='<div class="videodesp" '.$stylev.'>';
                     $strpos = strpos($videoaddress,'://');
                     if(is_int($strpos)){ 
                            $videoaddressloc = $videoaddress;
                     }
                     else $videoaddressloc = STAPATH.'video/'.$videoaddress;
             
            //video image
            if($videoimg=='') $videoimgv = STAPATH.'img/video.jpg';
            else  $videoimgv = UPLOADPATHIMAGE.$videoimg;
            
            $imgv.='<div class="media-wrapper">';
            $imgv.='<video id="player1" width="100%" height="100%" style="max-width:100%;" poster="'.$videoimgv.'" preload="none">';
            $imgv.='<source src="'.$videoaddressloc.'" type="video/mp4"> ';
            $imgv.='</video>';
            $imgv.='</div>';
            $imgv.='</div>';

          }

             else {
                $imgv.='<div class="videodesp">';
                $imgv.=   decode($videoaddress);
                $imgv.='</div>';
             }

       if($videotitle<>'')  $imgv.='<div class="videotitle">'.$videotitle.'</div>';

       $imgv.='</div>';
         
       
    
}

 
 

if($blockcntid=='bkcnt_imgleft' || $blockcntid=='bkcnt_videoleft' || $blockcntid=='bkcnt_blockidleft')
 {
  $w1text =  $imgv;
  $w2text = $despv;
    }
else  {
    $w1text = $despv;
    $w2text = $imgv;
   }


?>


 <div class="c col2 bkcntbox <?php echo $cssname;?>">
    <div class="w1"><?php echo $w1text;?></div>
    <div class="w2"><?php echo $w2text;?></div>
 </div>

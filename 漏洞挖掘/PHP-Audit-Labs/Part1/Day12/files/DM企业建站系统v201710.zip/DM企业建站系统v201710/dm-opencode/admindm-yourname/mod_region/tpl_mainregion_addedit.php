<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}

if($act=='insert')
 {
  if($abc1=="") $abc1 = 'pls input title'; 

  $pidname='regionindex'.$bshou;
 

			$ss = "insert into ".TABLE_REGION." (pid,pidname,pbh,name,type,lang,dateedit) values ('0','$pidname','$user2510','$abc1','index','".LANG."','$dateall')";
			 //echo $ss;exit;
			iquery($ss);
			alert('添加成功！');
			//jump($jumpvf.'&act=edit&pidname='.$pidname);
			jump($jumpv);
			
 
 }
 if($act=='update')
 {
     if($abc1=="") $abc1 = 'pls input title'; 


			 $ss = "update ".TABLE_REGION." set name='$abc1' where id='$tid' and type='index' $andlangbh limit 1";
			iquery($ss); 	
		 
			 jump($jumpv);
	 	
 }
 
 
 if($act=='add')
 { $titleh2= '添加区域';
 
 
 $name='';
 
 
 }
 
 if($act=='edit')
 {
 $titleh2= '修改区域';
  
 $jumpvinsert = $jumpvupdate.'&tid='.$tid; 
 
$sql = "SELECT * from ".TABLE_REGION."  where id='$tid' and type='index' $andlangbh order by id limit 1";
$row222 = getrow($sql);
if($row222=='no'){echo 'no record...';exit;}
//$desp=zbdesp_imgpath($row['desp']);
$name= $row222['name']; 
$type= $row222['type'];
 
 
 
}

 if($act=='add' or $act=='edit')
 {
?>
<div class="menu">
<a href="<?php echo $jumpv?>">返回列表</a>
</div>
<h2 class="h2tit_biao"><?php echo $titleh2;?></h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpvinsert?>" method="post">
  <table class="formtab">
    <tr>
      <td width="22%" class="tr">页面区域标题：</td>
      <td width="77%"> <input name="name" type="text" value="<?php echo $name?>" size="60">
       </td>
    </tr>


 
 
<tr>
      <td></td>
      <td>
      <input  class="mysubmit" type="submit" name="Submit" value="<?php echo $titleh2;?>"></td>
    </tr>
  </table>
</form>

 

<?php
}
?>

<script>
function checkhere(thisForm) {
   if (thisForm.name.value=="")
	{
		alert("请输入页面区域标题。");
		thisForm.name.focus();
		return (false);
	}
  
  

   // return;

}
 

</script>

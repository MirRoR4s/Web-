<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
  
*/

require_once '../config_a/common.inc2010.php';

ifhave_lang(LANG);//TEST if have lang,if no ,then jump

if($act <> "pos") zb_insert($_POST);

 
if(is_numeric($tid)) {   ifhasid(TABLE_MENU,$tid);}

if($ppid<>'') {ifhaspidname(TABLE_MENU,$ppid);}
else {echo 'sorry,must need ppid';exit;}

if($file=='') $file='list';
$filearr =  array("list", "cateadd", "cusaddedit", "pageadd", "pageedit");  
if(!in_array($file,$filearr))   {echo 'file is error.';exit;}

/********************************************/

$menuparent = get_field(TABLE_MENU,'name',$ppid,'pidname');

$title = '菜单管理 - '.$menuparent;
//.' - <a style="float:none;color:#0066CA" href="mod_mainmenu.php?lang='.LANG.'">< 返回菜单组</a>';


//
/************************/
 
$jumpv='mod_menu.php?ppid='.$ppid.'&lang='.LANG;
$jumpvf='mod_menu.php?ppid='.$ppid.'&lang='.LANG.'&file='.$file;
 

 
 
if($act == "sta_menu")
{ 
     $ss = "update ".TABLE_MENU." set sta_visible='$v' where id=$tid $andlangbh limit 1";	 
     iquery($ss);
    jump($jumpv);
}
if($act == "pos")
{
    foreach ($_POST as $k=>$v){
         $ss = "update ".TABLE_MENU." set  pos='$v' where id='$k'  $andlangbh limit 1";
         iquery($ss);
        }
      jump($jumpv);
}
//-------------------
if($act == "del")
{ 

 //$ifdel1 = ifcandel(TABLE_MENU,$pidname,'出错，有子菜单！',$jumpv);// back is fail 
//if($ifdel1){
 // ifsuredel(TABLE_MENU,$pidname,$jumpv);
  //}
 $ss = "select id from ".TABLE_MENU." where ppid='$ppid' and  pid= '$pidname' $andlangbh limit 1"; 
    $row = getrow($ss);
    if($row=='no'){
         $ss2 = "delete from ".TABLE_MENU."  where ppid='$ppid'  and pidname= '$pidname' $andlangbh limit 1";
     //echo $ss2.'<br />'; 
      iquery($ss2); 
      }
      else {alert('出错，有子菜单！');jump($jumpv); }


	
}

 

require_once HERE_ROOT.'mod_common/tpl_header.php';
?>
<?php //stylebhcntlink($stylebh);?>


<div class="menu">
 
<a href="<?php echo $jumpv;?>"><strong>管理列表</strong></a>
<a href="<?php echo $jumpv;?>&file=pageadd&act=add">添加单页面菜单</a>
<a href="<?php echo $jumpv;?>&file=cateadd&act=add">添加分类菜单</a>

<a href="<?php echo $jumpv;?>&file=cusaddedit&act=add">添加其他菜单</a>
 
</div>
<?php


require_once HERE_ROOT.'mod_menu/tpl_menu_'.$file.'.php'; 
require_once HERE_ROOT.'mod_common/tpl_footer.php';


?>
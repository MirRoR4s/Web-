<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}

 //if($act=='insert' or $act=='update'){


 // if($act=='insert') $jumpvhere =  $jumpvf.'&act=edit&tid='.$tid
 // else $jumpvhere = $jumpvf.'&act=edit&tid='.$tid; //&stylebh can from id

/*
if($type=='nd') {
   if(substr($abc2,0,3)<>'nd_') 
    {alert('效果文件要以nd_开头');
       jump($jumpvhere);

      }
}*/

// if($type=='vblock') {
//    if(substr($abc2,0,7)<>'vblock_') 
//     {alert('效果文件要以vblock_开头');
//        jump($jumpvhere);

//       }
// }


 //}
 //-------------------------

 if($act=='insert')
 { 


   $sql = "SELECT id from ".TABLE_BLOCK." where   effect='$abc3' and type='effect'    limit 1"; //$andlangbh 
   if(getnum($sql)>0){
       alert('对不起，添加重复！效果文件名不能重复。');
        $jumpvhere = $jumpvf.'&act=add';
       jump($jumpvhere);

   }
  
     if ($abc2 == '')   $abc2 = '请输入标题';     
   
 
     $pidname='effect'.$bshou;
			$ss = "insert into ".TABLE_BLOCK." (pidname,pbh,type,typeadmin,name,effect,desp,sta_visible,lang,dateedit) values ('$pidname','$user2510','effect','$abc1','$abc2','$abc3','$abc4','y','".LANG."','$dateall')";
		   //echo $ss;exit;
			iquery($ss);
			alert("添加成功");

			jump($jumpv);
}
	 	
 /*----update-----------------------------------*/
 
  if($act=='update')
 {   

    $sql = "SELECT id from ".TABLE_BLOCK." where  id<>'$tid' and   effect='$abc2' and type='$effecttype' and stylebh='$stylebh'   limit 1"; //$andlangbh 
   if(getnum($sql)>0){
       alert('对不起，这个效果名称存在！');
      jump($jumpvf.'&act=edit&tid='.$tid);  

   }



 if ($abc2 == '')  {alert('标题不能为空。'); jump($jumpvf.'&act=edit&tid='.$tid);exit;}
    
	 $ss = "update ".TABLE_BLOCK." set typeadmin='$abc1',name='$abc2',effect='$abc3',desp='$abc4',dateedit='$dateall' where id='$tid'  limit 1"; //$andlangbh
			iquery($ss); 	
		 // echo $ss;exit;
      //alert('修改成功。');
			  jump($jumpvf.'&act=edit&tid='.$tid);	 	
 }
  /*----add-----------------------------------*/
 
 
  if($act=='add')
 {
 $titleh2 = '添加效果';
 $jumpv_insert = $jumpvf.'&act=insert';

 $name = $desp =  $typeadmin = $effect = '';
 

 }
   if($act=='edit')
 {
  $titleh2 = '修改效果';

  $sql = "SELECT * from ".TABLE_BLOCK."  where id='$tid' order by id limit 1"; // $andlangbh
$row22 = getrow($sql);
 
$name = $row22['name']; 
$typeadmin = $row22['typeadmin'];
$effect = $row22['effect'];
$desp = $row22['desp'];

 
  $jumpv_insert = $jumpvf.'&act=update&tid='.$tid;


 }
 
 
 if($act=='add' or $act=='edit')
 {
?>
 <div class="menu">
<a href="<?php echo $jumpv?>">返回列表管理</a>
 
</div>

<h2 class="h2tit_biao"><?php echo $titleh2?> </h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpv_insert;?>" method="post" enctype="multipart/form-data">
  <table class="formtab">

     
     <tr>
      <td width="12%" class="tr">选择分类：</td>
      <td width="88%"> 
     <select name="typeadmin" class="staeffect">
<option  value="">请选择</option> 
   
 <?php 
 select_from_arr($arr_blocknd_type,$typeadmin,'');
 ?>

     </select> 
 <?php echo $xz_must?>

        </td>
    </tr>



    <tr>
      <td width="12%" class="tr">标题：</td>
      <td width="88%"> <input name="name" type="text"  value="<?php echo $name;?>" size="50">
      <?php echo $xz_must?>
        </td>
    </tr>
    
      <tr>
      <td width="12%" class="tr">效果文件名：</td>
      <td width="88%"> <input name="effect" type="text"  value="<?php echo $effect;?>" size="50">
          (不要带扩展名) 
      <?php echo $xz_must?>
 
	 <br /><span class="cgray">这个文件在 component/当前模板/effect/block下。</span>
         <?php 
         if($act=='edit'){
             $file = EFFECTROOTADMIN.'block/'.$effect.'.php';
            if(!is_file($file)) echo '<br /><span class="cred">文件:当前模板/'.'block/'.$effect.'.php不存在！</span>';
             
         }
         ?>
         
        </td>
    </tr>
    
       <tr>
      <td width="12%" class="tr">描述：</td>
      <td width="88%">
      <textarea name="desp" cols="120" rows="5"><?php echo $desp?></textarea>
      <?php echo $xz_maybe?>
        </td>
    </tr>

	  
	<tr>
      <td></td>
      <td>
      <input  class="mysubmit" type="submit" name="Submit" value="<?php echo $titleh2?>"></td>
    </tr>
	  </table>
</form>
 




<?php
}
?>

<script>
function checkhere(thisForm) { 
   if (thisForm.typeadmin.value=="")
  {
    alert("请选择分类。");
    thisForm.typeadmin.focus();
    return (false);
  }

   if (thisForm.name.value=="")
	{
		alert("请输入标题。");
		thisForm.name.focus();
		return (false);
	}
       if (thisForm.effect.value=="")
	{
		alert("请输入效果文件名。");
		thisForm.effect.focus();
		return (false);
	}
	 
	 
	
   // return;

}
 


</script>

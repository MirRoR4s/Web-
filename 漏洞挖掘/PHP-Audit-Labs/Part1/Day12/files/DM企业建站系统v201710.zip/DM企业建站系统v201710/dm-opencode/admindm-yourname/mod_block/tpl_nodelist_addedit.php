<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}
 
 if($act=='insert')
 {

  if($effect=='') {alert('need effect pidname value.');jump($jumpv);}
 

 
//     $pidregion = @$_POST['pidregion'];
 
// $wherepidregion = '';
// if(count($pidregion>0)){
//        $v3='';
//        if(is_array($pidregion)) {
//            foreach ($pidregion as $k2=>$v2){
//             $v3=$v3.$v2.'|';
//             }
//          }   
//         //$wherepidregion = ",pidregion= '$v3'";

// }

 /*
   if(substr($abc4,0,3)<>'nd_') 
    {alert('效果文件要以nd_开头');
       jump($jumpv);

      }
 
*/

    if ($abc1 == '')   {
     // alert('标题不能为空');
     // jump('mod_nodelist.php?lang='.LANG);
      $abc1 = '请输入标题';  
  }
      $pidnamehere='ndlist'.$bshou;
   
      //  $kv_v = "";
        $return_v ='';     
 

      $ss = "insert into ".TABLE_BLOCK." (pidname,pbh,type,pid,name,effect,maxline,cssname,more,dhpara,kv,lang,dateedit) values ('$pidnamehere','$user2510','nd','$abc2','$abc1','$effect','$abc3','$abc4','$abc5','$abc6','$return_v','".LANG."','$dateall')";
     //echo $ss;exit;
      iquery($ss);
      alert("添加成功");
     jump($jumpv);
    
 }
 
  if($act=='update')
 {
   //if($effpidname=='') {alert('need effectpidname value.');jump($jumpv);} //just need  show info
  if($pidname=='') {alert('need ndlist pidname value.');jump($jumpv);}




   if(@$_POST['inputmust']=='') {echo $inputmusterror.$backlist;exit;}

/*

   if(substr($abc4,0,3)<>'nd_') 
    {alert('效果文件要以nd_开头');
        jump($jumpvpf.'&act=edit');   

      }
 
*/
 

  if ($abc1 == '')   $abc1 = '请输入标题';


        $sql = "SELECT kv from ".TABLE_BLOCK." where pidname='$pidname'  $andlangbh   limit 1";
                           $row = getrow($sql);
                           $imgsqlname =$row['kv'];  
       
       $delimg = zbdesp_onlyinsert($_POST['delimg']);                            
    if($delimg=='y'){
        if($imgsqlname<>'') p2030_delimg($imgsqlname,'y','y');
        $kv_v = ",kv = ''";
    }
    else{

         $imgname = $_FILES["addr"]["name"];
       $imgsize = $_FILES["addr"]["size"];
       if (!empty($imgname)) {
           $imgtype = gl_imgtype($imgname);
           $up_small = 'n';
           $up_delbig = 'n';
           $up_water = 'n';           
           $i = '';
           require_once('../plugin/upload_img.php'); //need get the return value,then upimg part turn to easy.
           $kv_v = ",kv = '$return_v'";
       }
       else  $kv_v = "";
    
    }

 $ss = "update ".TABLE_BLOCK." set name='$abc1',pid='$abc2',maxline='$abc3',cssname='$abc4',more='$abc5',dhpara='$abc6'$kv_v,dateedit='$dateall' where pidname='$pidname' $andlangbh limit 1";
      iquery($ss);  
       // echo $ss;exit;
        jump($jumpvpf.'&act=edit');   
 }
 
 
  if($act=='add')
 {
 $titleh2 = '添加区块内容';
 $jumpv_insert = $jumpvf.'&act=insert&effect='.$effect;
 
$name = '';$more = '';
$maxline = '1';
 $dhpara=''; $cssname=''; $kv= $pidregion= '' ; 

 $previewlink='';
 }


   if($act=='edit')
 {
  $titleh2 = '修改区块内容';
  $jumpv_insert = $jumpvpf.'&act=update';

 $sql = "SELECT * from ".TABLE_BLOCK."  where pidname='$pidname'   $andlangbh order by id limit 1";
$row22 = getrow($sql);

$name = $row22['name'];$more = $row22['more'];$effect = $row22['effect'];

$maxline = $row22['maxline']; 
if($maxline <1) $maxline = 1;

$pidregion = $row22['pidregion']; 
 
 $pid= $row22['pid']; 
$dhpara= $row22['dhpara'];//$trigger= $row22['dhtrigger']; dhtrigger no use.use rand in front
$cssname= $row22['cssname'];
  $kv= $row22['kv'];
 $imgsmall2 = p2030_imgyt($kv, 'y', 'n');

 $previewlink = '<a target="_blank" href="'.$userurl.'previewofndlist&tov='.$pidname.'='.LANG.'">[预览]</a>';

 }
 
 
 if($act=='add' or $act=='edit')
 {
?>
 
<h2 class="h2tit_biao">

    <?php
    if($act=='edit')
 {
    $del_text= " <a href=javascript:del('delblock','$pidname','$jumpv')  class='fr but2'>删除区块</a>";
    echo $del_text;
    }
    ?>

<?php echo $titleh2?>
  &nbsp;&nbsp;&nbsp;&nbsp;
 <a href="<?php echo $jumpv?>">< 返回管理列表</a> 

</h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpv_insert;?>" method="post"  enctype="multipart/form-data">
  <table class="formtab">
    <tr>
      <td width="12%" class="tr">区块说明：</td>
      <td width="88%"> <input name="name" type="text"  value="<?php echo $name;?>" size="50">
  <?php echo $xz_must?>
  <?php echo $previewlink;?>
    
        </td>
    </tr>
   <tr>
      <td width="12%" class="tr">分类标识：
 <br /><a target="_blank" href="../mod_category/mod_category.php?lang=<?php echo LANG?>">内容分类 里找标识</a>
 <br /><a target="_blank" href="../mod_category/mod_taxo.php?lang=<?php echo LANG?>&type=blockdh">效果分类 里找标识</a>

        </td>
      <td width="88%"> 
    
    <input name="bs" type="text"  value="<?php echo $pid;?>" size="50"><?php echo $xz_must?>

    
  
     <?php
if($act=='edit'){ 
    $ssacte = "select * from ".TABLE_CATE." where pidname= '$pid'   $andlangbh limit 1";
   if(getnum($ssacte)<=0) echo '<span class="cred"><br />注意，此分类标识不存在，请检查。</span>';
   else {
     $catearr = get_fieldarr(TABLE_CATE,$pid,'pidname');
   
     $catepid = $catearr['pid'];
     if(substr($pid,0,4)=='csub') {
      //get main cate
      if(substr($catepid,0,4)=='csub')   $maincatepidname = get_field(TABLE_CATE,'pid',$catepid,'pidname');
      else  $maincatepidname = $catepid;
 
     }
     else $maincatepidname = $pid;


       $catearr2 = get_fieldarr(TABLE_CATE,$maincatepidname,'pidname');
       $modtype = $catearr2['modtype'];
       $maincatename = $catearr2['name'];

    
    //$catelink = '<a target="_blank" href="../mod_category/mod_category.php?lang='.LANG.'&catid='.$maincatepidname.'">(查看分类)</a>';
 
 //mod_node/mod_blockdh.php?lang=en&catpid=cate20160713_0504261721&page=0&catid=csub20160826_0439123901
 
   $nodelink = '../mod_node/mod_'.$modtype.'.php?lang='.LANG.'&catpid='.$maincatepidname.'&page=0&catid='.$pid;
 
 

  echo '<a target="_blank" href="'.$nodelink.'">(管理内容)</a>';
   

   }


   
  }
  else {
  //echo ' &nbsp; &nbsp; | &nbsp;<a target="_blank" href="../mod_category/mod_category.php?lang='.LANG.'">选择分类</a>';
}
 ?>
    
        </td>
    </tr>





   <tr>
      <td width="12%" class="tr">效果模板文件：</td>
      <td width="88%" height="60"> 
<?php
//if($act=='add') echo '<span class="cgray">添加时，程序会自动分给一个模板。如果这个模板不是你需要的，请再编辑它。</span>';
//else echo '<a href="mod_selecteffect.php?lang='.LANG.'&pidname='.$pidname.'" target="_blank"><strong>选择效果文件 ></strong></a>';
 
  $effarr = get_fieldarr(TABLE_BLOCK,$effect,'pidname'); 
echo $effarr['name'].' - 效果模板文件：'.$effarr['effect'];


  ?>
  
 

        </td>
    </tr>




    <tr>
      <td width="12%" class="tr">显示个数：</td>
      <td width="88%"> 
     <input name="num" type="text"  value="<?php echo $maxline;?>" size="10"><span class="cgray">（为数字，且大于0）</span>
     <?php echo $xz_must?>
        </td>
    </tr>
    



      <tr>
      <td width="22%" class="tr">样式名称：</td>
      <td width="77%"> <input name="cssname" type="text" class="inputcss" value="<?php echo $cssname?>" size="60"><?php echo $xz_maybe; ?> 
<br />
      <span class="cgray">参考：notitle , nodesp   </span>
       </td>
    </tr>
 <tr>
      <td width="22%" class="tr">更多链接的字样：</td>
      <td width="77%"> <input name="more" type="text" value="<?php echo $more?>" size="20"><?php echo $xz_maybe; ?> 
      <br /><span class="cgray">(比如 查看详情 ， 课程详情等。)</span>
       </td>
    </tr>
 <tr>
      <td width="22%" class="tr">动画参数：</td>
      <td width="77%">
      <textarea cols="100" name = "dhpara" rows="10"><?php echo $dhpara; ?></textarea>
 <?php echo $xz_maybe; ?> 
      
       </td>
    </tr>



 

<?php if($act=='edit'){?>

   <tr>
            <td width="12%" class="tr">效果的图片示例：</td>
            <td width="88%"> <input name="addr" type="file" id="addr" size="50" /><?php echo $xz_maybe;?>  
<?php
echo '<br /><span class="cred">' . $format_t . '</span><br />';
// echo gl_showsmallimg($fo_bef,$imgsmall,'y');
   if($kv<>'')    echo $imgsmall2;
?>
             
    <?php  if($kv<>'')    {
              ?>
          <span class="cred"> <br />是否要删除图片？ </span> 
          <select name="delimg">
    <?php select_from_arr($arr_yn,'n','');?>
     </select>
          <?php } 
          else{ //use for : Undefined index: delimg 
              ?>          
          <select name="delimg" style="display:none">
              <option value=""></option>
     </select>
          <?php
          }?>
              
              <br />  <br />  
</td></tr>

<?php  } ?>
  <tr>
      <td></td>
      <td>
      <input  class="mysubmit" type="submit" name="Submit" value="<?php echo $titleh2?>"></td>
    </tr>
    </table>

     <?php echo $inputmust;?>

</form>
 

<?php
}
?>

<script>
function checkhere(thisForm) {
   if (thisForm.name.value=="")
  {
    alert("请输入区块说明。");
    thisForm.name.focus();
    return (false);
  }
    
    if (thisForm.bs.value=="")
  {
    alert("请输入分类标识。");
    thisForm.bs.focus();
    return (false);
  }
 
/*
var effbegin = thisForm.effect.value.substring(0,2);
     //alert(effbegin);
if(effbegin!='nd'){
    alert("效果文件要以nd_开头");
    thisForm.effect.focus();
    return (false);
  }
*/

   
 
   var reg=/^[0-9]*$/;
      if (thisForm.num.value=="")
  {
    alert("请输入显示个数。");
    thisForm.num.focus();
    return (false);
  }
  else{
   var testnum = reg.test(thisForm.num.value);
   if(!testnum){
       alert(" 显示个数 要为数字。");
    thisForm.num.focus();
    return (false);
   
   }
   
  }
 var num=thisForm.num.value; 
 // return;

}
 
/*
 $(function(){

  staeffect($('.statype').val(),'');

     $('.statype').change(function(){        
        staeffect($(this).val(),'y');
     });
 });


 function staeffect(v,setfirst){
      $('.staeffect option').each(function(){
           var thistext = $(this).text();

            if(thistext.indexOf(v)==-1) $(this).hide();
            else $(this).show();


      });
    

       if(setfirst=='y')    $(".staeffect option:first").show().attr('selected','true');
    

 }*/

</script>

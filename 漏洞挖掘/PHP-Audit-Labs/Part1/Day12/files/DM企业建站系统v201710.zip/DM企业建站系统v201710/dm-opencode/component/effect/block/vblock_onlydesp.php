
<div class="bkcntbox blockonlydesp <?php echo $cssname;?>">

<?php 
echo $imgv2;

if($blockid<>'') block($blockid);

echo $despv;

?>


</div>
<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}

//echo strlen('lunh1/20100514_1637283869.jpg');--29
?>

<?php
 //if($type=='index')  stylebhcntlink($stylebh);?>


<div class="menu"> 
<a href="<?php echo $jumpv?>&file=addedit&act=add">添加</a> 
</div>
 
 
<form method=post action="<?php echo $jumpvpf;?>&act=posmain">
<table class="formtab formtabhovertr">
<tr style="background:#B3C0E0">
<td width="100" align="center">排序</td> 
<td width="450">标题</td>
<td width="250" align="center">属性</td>
<td width="120" align="center">预览</td>
<td width="120" align="center">管理</td>
<td  align="left">操作</td>
</tr>


<?php
 
 
$sql = "SELECT id,name,pidname,pos,cssname,sta_width_cnt from ".TABLE_REGION." where pid='0' and type='$type'  $andlangbh  order by  pos desc,id desc";
  // echo $sql;
if(getnum($sql)>0){
$rowlist = getall($sql);
    foreach($rowlist as $vcat){
       $tidmain=$vcat['id']; //tidmain ,not use tid,for conflict in subedit.php
       $name=$vcat['name']; 
       $pidnamecur=$vcat['pidname'];  $cssname=$vcat['cssname'];  
       $sta_width_cnt=$vcat['sta_width_cnt']; 

    if($pidname==$pidnamecur) $curclass=' style="color:#fff;background:red;padding:3px;" ';
    else $curclass=' ';


 $previewlink = $userurl.'previewofndlist&tov='.$pidnamecur.'='.LANG;

       $namev = '<a '.$curclass.' href="'.$jumpv.'&pidname='.$pidnamecur.'&file=list&act=list"><strong>'.$name.'</strong></a>';
       //$namev = '<a '.$curclass.' href="'.$jumpv.'&pidname='.$pidnamecur.'&file=mainedit&act=edit"><strong>'.$name.'</strong></a>';
  $edit =  '<a class="but2"  href="'.$jumpv.'&file=addedit&tid='.$tidmain.'&act=edit"><span  class="bg22">修改</span></a>';
  $del =" | <a class='but1'  href=javascript:del('delregion','$pidnamecur','$jumpv')><span  class='bg22' >删除</span></a>";
 

$gl =  '<a  class="but3"  href="mod_regcommon.php?lang='.LANG.'&pid='.$pidnamecur.'"><span  class="bg22">管理</span></a>'; 

     ?>
    <tr class="subregion_<?php echo $sta_sub;?>">
    <td align="center"><input type="text" name="<?php echo $tidmain;?>"  value="<?php echo $vcat['pos'];?>" size="5" /></td>
   <td align="left"><strong><?php echo $name?></strong>
   <br />
   <span class="cgray">标识:<?php echo $pidnamecur?> </span>
   </td>

   <td align="center">
  <?php 
    echo '<span class="cgray">是否全宽: '.$sta_width_cnt.'</span>';
       if($cssname<>'') echo '<br /><span class="cgray">css名称: '.$cssname.'</span>';
?> 
   </td>

     <td align="center">
 <a style="color:#666" href="<?php echo $previewlink;?>" target="_blank">预览<i class="fa fa-link"></i></a> 
     </td>
  <td align="center">
      <?php echo $gl?>
     </td>
  <td align="left">
          <?php echo $edit.$del?>
     </td>


    </tr>
    <?php 
    } 
    ?>
  

    <?php }
    else echo '<tr><td colspan="3"> 暂无内容，请添加。<td><tr>';



//----------------
//}
//---------------



?>
</table>
  <div style="padding-bottom:22px"><input class="mysubmit" type="submit" name="Submit" value="排序" /><?php echo $sort_ads?></div>
  </form>

 
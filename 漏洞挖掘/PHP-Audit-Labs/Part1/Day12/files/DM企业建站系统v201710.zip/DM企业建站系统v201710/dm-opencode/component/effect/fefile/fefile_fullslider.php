<?php 
$sqlall="select * from ".TABLE_NODE." where pid='csub20170110_1208298299' and sta_visible='y' $andlangbh  order by pos desc,id desc";
if(getnum($sqlall)>0){
 ?>
<div class="homefullsliders dmfull_height bxarrow1">
  <ul>
    
 <?php 
   $result = getall($sqlall);


foreach ($result as $v) {
 $tid = $v['id'];
 $title = $v['title']; 
 $kv = $v['kv'];

  if($kv<>'') $imgv = UPLOADPATHIMAGE.$kv; 
   else $imgv = DEFAULTIMG;
 
 $linkurl = $v['linkurl'];
 
$despjj= $v['despjj'];

 
    $desp= web_despdecode($v['desp']);
      $desptext= web_despdecode($v['desptext']);
      $despv='';
      if($desptext<>'') $despv = $desptext;
      else  $despv = $desp;
 
 
 $bgimgv= 'background:url('.$imgv.');';



 ?>
    <li style="<?php echo $bgimgv?>">
      
      <div class="text">
      <div class="textinc">
        <h2><?php   echo $title;  ?></h2>
        <h3><?php   echo $despjj;  ?></h3>
        <p><?php   echo $despv;  ?></p>
        <div class="bkmore dmbtn more3">
        <a class="more"  href="<?php   echo $linkurl;  ?>" class="btn button button--red triangle">查看详情 ></a>
        </div>
      </div>
       </div>
    </li>

 <?php 
}
 ?>
 
  </ul>
</section><!--sliders-->

<?php 
}
else echo '幻灯片没有内容或处于隐藏状态';
?>
 
 
<script>
$(function(){
  $('.homefullsliders>ul').bxSlider({ 
 auto:'auto',
 controls:true //如果是false，可以把左右箭头取消

 });


});
</script>

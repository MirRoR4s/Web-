<?php
/*
  欢迎使用DM建站系统，网址：www.demososo.com
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}
//----------
 
?> 
<h2 class="h2tit_biao"> 
<a href="<?php echo $jumpv?>">< 返回区域</a>
</h2>
 
<div class="menusub" style="margin-top:22px;">

<?php

//--------------
 $editcan_cur=  $editstyle_cur=$editlink_cur=$edittitle_cur=$editcfg_cur='';

 if($file=="editcan")   $editcan_cur=' cur'; 
 elseif($file=="editcfg")   $editcfg_cur=' cur';
 elseif($file=="editstyle")   $editstyle_cur=' cur';
 elseif($file=="editlink")   $editlink_cur=' cur';
elseif($file=="edittitle" || $file=="edittitlecenter")   $edittitle_cur=' cur';
//mod_region_edit.php?lang=cn&pidname=region20160307_1119576083&file=edit&act=edit&tid=127

 
echo '<a class="bg22'.$editcan_cur.'" href="'.$jumpv.'&act=edit&file=editcan&tid='.$tid.'"><span  class="bg22" >修改标题</span></a>';


echo '<a class="bg22'.$editcfg_cur.'" href="'.$jumpv.'&act=edit&file=editcfg&tid='.$tid.'"><span  class="bg22" >修改样式</span></a>';

 
?>
 
 

</div>

 
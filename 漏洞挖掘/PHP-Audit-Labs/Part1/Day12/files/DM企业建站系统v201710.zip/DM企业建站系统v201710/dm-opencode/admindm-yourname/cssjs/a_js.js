//add..............
$(document).ready(function(){
   
	 xiala_show('navlang');xiala_show('navblock');xiala_show('navcate');
tab();	 
//stopsubmit();
editmenuother();
//popup();
/**/
$('.bgmask').click(function(event) {
	      //$('.bgmask').hide();
           // $('.popcontent').hide();
		     $(this).hide();//bgmask
             $(this).prev().hide();
			 
});

	$('.formtabhovertr tr').hover(function(){
	   $(this).addClass('hovertr');
	},function(){
	    $(this).removeClass('hovertr');
	});

$('.needpopup').click(function(e) {
	  e.preventDefault(); 
	  //alert($(this).attr('href'));
	  popupneed($(this).attr('href'));
	  return false;
});

$('.popclose').click(function(){ 
		  //$('.bgmask').hide();
           // $('.popcontent').hide();
		    $(this).parent().next().hide();//bgmask
             $(this).parent().hide();

});

$('.headeruser img').click(function(event) {
	 $('.headeruserinc').toggle();//slideToggle
});

//---------end ready----------------------------------------
}); //end ready

function editmenuother(){   
		   $(".editmenuother").click(function(){ 
			  $(".editmenuother_cnt").slideToggle();
			});
}

function stopsubmit(){
     $('input[type=submit]').click(function(){

       // alert(0);

     });
}//end func


function xiala_show(classname){
$("."+classname).hover(
	  function () {  
		//$(".navlang ul").addClass("hover");
		$(this).children(".xialabox").show();
	  },
	  function () {
		//$(".navlang ul")removeClass("hover");
		$(this).children(".xialabox").hide();
	  }
	);
//
}//end func

function tab(){ 
$(".tab span").click(function(){
thisindex =$(this).index()+1;
$(".tab span").toggleClass('cur');
$(".tabarea>div").hide();
$(".tabarea .tab"+thisindex).show();
 

});
//
}//end func



 function  setdefault(actgo2,tid,backpage,textv){  
   // if (confirm(text)){
      golink  = backpage+'&act='+actgo2+'&tid='+tid;
	//alert(golink);
      // window.location=golink;
    //}
	 
		popupconfirm(textv,golink);
		
}


function  activatestyle(actgo2,pidname,backpage){  
    //if (confirm("确定启动这个模板？这会直接影响前台效果！")){
      golink  = backpage+'&act='+actgo2+'&pidname='+pidname;
  //alert(golink);
      // window.location=golink;
   // }
	var textv ='确定启动这个模板？这会直接影响前台效果！';
		popupconfirm(textv,golink);
		
}



function  del(actgo2,pidname,backpage){  
    //if (confirm("确定删除?不能恢复")){
      golink  = backpage+'&act='+actgo2+'&pidname='+pidname;
	//alert(golink);
       //window.location=golink;
    //}
	var textv ='确定删除?不能恢复!';
		popupconfirm(textv,golink);
}
function  del2(actgo2,pidname,pidname2,backpage){  //when del region sub
    //if (confirm("确定删除?不能恢复")){
      golink  = backpage+'&act='+actgo2+'&pidname='+pidname+'&pidname2='+pidname2;
	//alert(golink);
      // window.location=golink;
    //}
	var textv ='确定删除?不能恢复!';
		popupconfirm(textv,golink);
}
function  delid(actgo2,id,backpage){  
    //if (confirm("确定删除?不能恢复")){
      golink  = backpage+'&act='+actgo2+'&tid='+id;
	//alert(golink);
      // window.location=golink;
    //}
	var textv ='确定删除?不能恢复!';
		popupconfirm(textv,golink);
		
}

function  delimg(actgo2,tid,imgv,backpage){  
    //if (confirm("确定删除?不能恢复")){
     golink  = backpage+'&act='+actgo2+'&tid='+tid+'&v='+imgv;//imgv no use
	//alert(golink);
      // window.location=golink;
   // }
	var textv ='确定删除?不能恢复!';
	 popupconfirm(textv,golink);
	 
}




function  isnum(v){  //alert(v);
    if(!isNaN(v)){return true;
  			// alert("是数字");
		}
	else{return false;
		   //alert("不是数字");
		}

	/*
	    var pos=thisForm.pos.value;
    //正则表达式，需要注意的是这里并没有引号，而是用//
    var reg=/^[0-9]*$/;
    if(!reg.test(pos)){
	   alert("pos必须是数字");	
		thisForm.pos.focus();
		return (false);
   
   }
   */	 
		 
}
 
// gosele
function gosele(sobj,can,jumpv) {
	var thevalue =sobj.options[sobj.selectedIndex].value;
	if (thevalue != "") {
	//alert(docurl);
	var gov =  jumpv+can+'='+thevalue;
	//alert(gov);
	 location.href=gov;
	  // open(docurl,'_blank');
	  // sobj.selectedIndex=0;
	  // sobj.blur();
	}
}






function popupneed(iframev){ 
	if(iframev=='') var iframev = '../mod_common/iframeblank.php';
	 $('#popiframe').attr('src',iframev);
	 popup_go('need','.popcontent');
 }
 
 function popupconfirm(textv,linkv){  
    $('.popcontentconfirm .popcontentinc p').html(textv);
	$('.popcontentconfirm .link a').attr('href',linkv);
 
	 popup_go('confirm','.popcontentconfirm');
 }
 

function popup_go(type,v){
   popupName = $(v);
 var _scrollHeight = $(document).scrollTop(), 
     _windowH = $(window).height(), 
     _windowW = $(window).width(), 
     _popupH = popupName.height(), 
     _popupW = popupName.width()+40; 
     _posiTop = (_windowH - _popupH)/2 + _scrollHeight;
     if(type=='confirm') _posiTop = _posiTop-150;


     _posiLeft = (_windowW - _popupW)/2;
 popupName.css({"left": _posiLeft + "px","top":_posiTop + "px"}); 
  
  bgH = $(document).height();
  $('.bgmask').css({height:bgH+'px'});
   
			if(type=='need')   { 
					$('.bgmaskneed').show();
					$('.popcontentneed').show();
			}
			if(type=='confirm')   { 
					$('.bgmaskconfirm').show();
					$('.popcontentconfirm').show();
			}
			
			 
   
}


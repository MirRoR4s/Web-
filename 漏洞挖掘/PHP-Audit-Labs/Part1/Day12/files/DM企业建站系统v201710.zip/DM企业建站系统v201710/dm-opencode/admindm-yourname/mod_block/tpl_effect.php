<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}

?>


 
 <?php 
if($file=='') $file='list';
 require('tpl_effect_'.$file.'.php');
 ?>
 

 
<div class="c"></div>

<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}
//echo 'no use';exit;
?>

 
<div class="allcord">

<span style="margin-right:30px;"><a target="_blank" class="needpopup db" style="color:#fff;" href="mod_effect.php?lang=<?php echo  LANG?>">管理效果文件</a></span>

<span class="zhan">全部关闭</span></div>
<?php global $andlangbh;

  $i=0;
   foreach($arr_blocknd_type as $k=>$v){  //foreach_1
    $i++;
               ?>
 

<div class="maineff">
   <div class="maintitle">
       <span class="fr icon accord accordcur"></span>
       <?php echo $v?>
 
        </div>
<?php
  $sql = "SELECT * from ".TABLE_BLOCK." where  type='effect' and typeadmin='$k'   order by pos desc,pidname desc,id desc";
// echo $sql;
$rownum = getnum($sql);
if($rownum>0) {  //if_1
  echo '<ul class="subeff">';
    $rowlist = getall($sql);
    foreach($rowlist as $v){ //foreach_2
      $name = $v['name'];$tid = $v['id'];
       $effect = $v['effect'];//file
        $effpidname = $v['pidname'];//ndlist effect
    ?>

    <li class="subli"> <div class="subtitle">

    <?php echo $name?>
  <a target="_blank"   href="mod_nodelist.php?file=addedit&act=add&effect=<?php echo $effpidname?>&lang=<?php echo  LANG?>">添加</a>
    </div>

        <?php 
              $sql2 = "SELECT * from ".TABLE_BLOCK." where  type='nd' and effect='$effpidname'   order by id desc";
              // echo $sql2;
              $rownum2 = getnum($sql2);
              if($rownum2>0){ // if_2
                echo '<ul class="ndlist">';
                 $rowlist2 = getall($sql2);
                     foreach($rowlist2 as $v2){ //foreach_3
                       $name2 = $v2['name'];$pidnamecur=$v2['pidname'];  
                        $kv=$v2['kv'];
                         //$imgsmall2 = p2030_imgyt($kv, 'y', 'n');
                        $kv = '<img src='.get_img($kv, '', '').' alt="" width="150" height="150" />';
    $editv = '<a class="but1" target="_blank" href="'.$jumpv.'&pidname='.$pidnamecur.'&file=addedit&act=edit">修改</a> ';
  
                          $previewlink = $userurl.'previewofndlist&tov='.$pidnamecur.'='.LANG;

                        ?>
                            <li>                                                        
                            <div class="img">
                            <?php 
                            echo '<a href="'.$previewlink.'" title="预览"  target="_blank">';
                              echo $kv;
                             echo '</a>';
                            ?>
                            </div>
                            <h3  class="name"><?php echo $name2;?></h3>                            
                            <div class="bs">标识： <?php echo $pidnamecur;?></div> 
                            <div class="edit">
                             <?php   echo $editv ;   ?>
                            </div>
                             

                            </li>


                        <?php
                       }//end foreach_3
                echo '<div class="c"></div></ul>';
              } //end if_2
              else {echo '<p>暂无内容</p>';}


        ?>
   






    </li>

     
    <?php  
    }//end foreach_2
    echo '<div class="c"></div></ul>';
} //end if_1 
?>
 </div><!--end maineff-->
 <?php
}//foreach_1
?>



 

 
<div class="c"></div>
 
 

 <script>
$(function(){

   $(window).scroll(function(){
      if($(this).scrollTop()>100)
      {
        $('.allcord').addClass('allcordfixed')
    } 
   else  $('.allcord').removeClass('allcordfixed')
 });

   //----------------


  
      $('.maintitle').click(function(event) {
        /* Act on the event */

           $(this).next().toggle();
           $(this).find('.accord').toggleClass('accordcur');
      });
//------------

  $('.allcord span.zhan').click(function(event) {
        /* Act on the event */
         if($(this).hasClass('allaccordopen')){ //close
             $('.subeff').show();
           $(this).removeClass('allaccordopen');          
            $(this).text('全部关闭');
            $('.maineff .accord').removeClass('accordcur').addClass('accordcur');

         }
         else{ //open
           $('.subeff').hide();    
             $(this).addClass('allaccordopen');       
            $(this).text('全部展开');
            $('.maineff .accord').removeClass('accordcur');
          }
            
      });
//-------
  


  //------------
});

</script>
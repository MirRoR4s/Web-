</div><!--end tit_biao_bot-->
</div><!--end newcnt-->
 

<div class="popcontent popcontentneed" style="display:none"> 
<span    class="popclose"></span>
<div class="popcontentinc">
<iframe width="100%" id="popiframe" height="100%" frameborder="0"  scrolling="auto"   src="../mod_common/iframeblank.php"> </iframe>
 </div> 
 </div> 
 <div class="bgmask bgmaskneed"> </div>


 <div class="popcontent popcontentconfirm" style="display:none"> 
<span    class="popclose"></span>
<h3>确定操作吗？</h3>
<div class="popcontentinc">
      <p></p>

     
      <div class="cancel"><span style="color:red">如果取消</span>，请点击右上角关闭窗口。</div>
       <div class="link"><a href="">确定</a></div>

  </div> 
 </div> 
 <div class="bgmask bgmaskconfirm"> </div>



 
 
</body>
</html>
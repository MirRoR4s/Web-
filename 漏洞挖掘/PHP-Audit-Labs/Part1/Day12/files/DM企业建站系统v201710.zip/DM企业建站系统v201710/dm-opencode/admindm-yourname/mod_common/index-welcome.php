<?php

/*

    //act:list edit del delimg updatetime submit(update add )
*/
$mod_previ = 'other';//default is admin,and set in common.inc
require_once '../config_a/common.inc2010.php';
$title = '后台首页';
//
require_once HERE_ROOT.'mod_common/tpl_header.php';
require_once HERE_ROOT.'mod_common/tpl_index.php';

require_once HERE_ROOT.'mod_common/tpl_footer.php';


//echo "$hotellist<pre>".print_r($_POST,1)."</pre><hr>";
//echo 'kk';
//echo substr($_FILES['addr']['name'],-3);
?> 
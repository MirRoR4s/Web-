<?php
/*http://www.wookmark.com/jquery-plugin   http://code.ciaoca.com/jquery/wookmark/
*/
?>

 <div id="mainwookmark" role="mainwookmark">

      <ul id="tiles">
        <!-- These are our grid blocks -->
        <li><img src="http://www.demososo.com/bg/wookmark/image_1.jpg" width="200" height="283"><p>1</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_2.jpg" width="200" height="300"><p>2</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_3.jpg" width="200" height="252"><p>3</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_22.jpg" width="200" height="297"><p>4</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_4.jpg" width="200" height="158"><p>5</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_33.jpg" width="200" height="297"><p>6</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_5.jpg" width="200" height="300"><p>7</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_6.jpg" width="200" height="297"><p>8</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_66.jpg" width="200" height="297"><p>9</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_7.jpg" width="200" height="200"><p>10</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_8.jpg" width="200" height="200"><p>11</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_99.jpg" width="200" height="297"><p>12</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_9.jpg" width="200" height="398"><p>13</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_10.jpg" width="200" height="267"><p>14</p></li>
        <li><img src="http://www.demososo.com/bg/wookmark/image_66.jpg" width="200" height="297"><p>15</p></li>
    
        <!-- End of grid blocks -->
      </ul>


    </div>


  <div class="loadingbar" style="padding:20px;text-align:center;display:none"></div>
  <div class="wookmarkend" style="color:red;padding:20px;text-align:center;font-size:30px"> </div>

<style type="text/css">
#mainwookmark {  margin: 30px 0;  position: relative;}
#tiles{list-style-type:none;position:relative;margin:0;padding:0}
#tiles li{width:250px;background-color:#ffffff;border:1px solid #dedede;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;display:none;cursor:pointer;padding:4px}
#tiles li.inactive{visibility:hidden;opacity:0}
#tiles li img{display:block;width:100%;height: auto}
#tiles li p{color:#666;font-size:13px;line-height:20px;text-align:center;font-weight:200;margin:7px 0 2px 7px}
</style>
  <!-- Once the page is loaded, initalize the plug-in. -->
  <script type="text/javascript">
    (function ($){
      var $tiles = $('#tiles'),
          $handler = $('li', $tiles),
          $main = $('#mainwookmark'),
          $window = $(window),
          $document = $(document),
          options = {
            autoResize: true, // This will auto-update the layout when the browser window is resized.
            container: $main, // Optional, used for some extra CSS styling
            offset: 20, // Optional, the distance between grid items
            itemWidth: 260 // Optional, the width of a grid item
          };

      /**
       * Reinitializes the wookmark handler after all images have loaded
       */
      function applyLayout() {
        $tiles.imagesLoaded(function() {
          // Destroy the old handler
          if ($handler.wookmarkInstance) {
            $handler.wookmarkInstance.clear();
          }

          // Create a new layout handler.
          $handler = $('li', $tiles);
          $handler.wookmark(options);
        });
      }

      /**
       * When scrolled all the way to the bottom, add more tiles
       */
       var page=1;
      function onScroll() {
        // Check if we're within 100 pixels of the bottom edge of the broser window.
        var winHeight = window.innerHeight ? window.innerHeight : $window.height(), // iphone fix
            closeToBottom = ($window.scrollTop() + winHeight > $document.height() - 100);
    
      if(page<8){
              if (closeToBottom) {
                  $('.loadingbar').show(); 
                // Get the first then items from the grid, clone them, and add them to the bottom of the grid
                var $items = $('li', $tiles),
                    $firstTen = $items.slice(0, 10);
                $tiles.append($firstTen.clone());

                applyLayout();

                page++;
              }
           }
           else if(page==8) {// alert('没有数据了!');
                               page++;
                               $('.wookmarkend').text('没有数据了!');
                               $('.loadingbar').hide(); 
                            }
           else {}
      };

      // Call the layout function for the first time
      applyLayout();

      // Capture scroll event.
      $window.bind('scroll.wookmark', onScroll);
    })(jQuery);
  </script>
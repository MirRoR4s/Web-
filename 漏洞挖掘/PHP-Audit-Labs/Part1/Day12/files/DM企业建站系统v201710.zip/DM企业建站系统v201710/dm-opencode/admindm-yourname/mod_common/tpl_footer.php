</div><!--end tit_biao_bot-->
</div><!--end newcnt-->
<div style="padding:5px;border-top:1px solid #ccc;text-align:center;background:#eee;margin-top:22px">
建议使用1280*1024以上分辨率。
 <a target="_blank" href="http://www.demososo.com/color.html">配色方案></a>
<br />
&copy;DM企业建站系统 <a href="http://www.demososo.com" target="_blank">demososo.com</a> 版权所有    <span class="cp listclassname">查看样式</span></div>

<div class="tc listclassnamecnt" style="display:none">
 图文：gridcol2 , gridcol2divi（2列里再2列）, gridcol2divi_2(我们的服务) 
cirimg , zoomimgwrap , gridboxshadow
<br>
gridnomag (def is 5) , gridnomag2 , gridnomag3  , gridnomag4   
<Br /> 列表：#listnode  videoarrow gridcolbg （hover bg） 
<Br />固定高： gridcolhg120   gridcolhg150  gridcolhg180   gridcolhg210   gridcolhg240   gridcolhg270  gridcolhg300 
<Br />固定宽： gridcolimg100 gridcolimg80 gridcolimg60 默认是80%
<br >前台： bxautono  hidecontent_cainiaoyz    bgboxcontent 
titlelineawe
<br />
minheight500 minheight350   maxheight (def:420px)  maxheight350 maxheight250
<br>css for php: 
<br>displayall, bgvideo, notitle, 
<br>gceng的图文：gridbigimg, g2cengjia(def，不用),g2cengkuo,g2cengkuotitle,g2cengarrow
<br>grid: useiconimg,morehover ,  

<br><br>
<br>按钮：  默认是蓝色，其他选择：more1 透明 , more1b 透明2 , more2 白色，more3 黑色，more4 红色，more5 橙色，more6 绿色，more7 紫色 
<br>按钮：高：moresm , moresm2 , 宽：moresmw ，moresmw2  ,直角： morenocir 
</div>


<div class="popcontent popcontentneed" style="display:none"> 
<span    class="popclose"></span>
<div class="popcontentinc">
<iframe width="100%" id="popiframe" height="100%" frameborder="0"  scrolling="auto"   src="../mod_common/iframeblank.php"> </iframe>
 </div> 
 </div> 
 <div class="bgmask bgmaskneed"> </div>


 <div class="popcontent popcontentconfirm" style="display:none"> 
<span    class="popclose"></span>
<h3>确定操作吗？</h3>
<div class="popcontentinc">
      <p></p>

     
      <div class="cancel"><span style="color:red">如果取消</span>，请点击右上角关闭窗口。</div>
       <div class="link"><a href="">确定</a></div>

  </div> 
 </div> 
 <div class="bgmask bgmaskconfirm"> </div>


 
<script>
$(function(){
	$('.listclassname').click(function(){
		 $('.listclassnamecnt').toggle();
		
	});
	   
	
});
</script>
</body>
</html>
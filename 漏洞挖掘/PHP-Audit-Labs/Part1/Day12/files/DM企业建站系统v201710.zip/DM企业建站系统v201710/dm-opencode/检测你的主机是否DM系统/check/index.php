<?php

 
$file = @htmlentities($_GET['file']);

echo $file;

?>
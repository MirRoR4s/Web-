<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}


?>

<div class="pa20" style="line-height:35px;font-size:16px;padding-bottom:200px">
 


欢迎使用DM企业建站系统，<br />
DM系统专注中小企业网站建设！<br />
DM系统开源，免费，无需授权！<br />
您值的拥有！ 
<br /><br />
<span style="color:red;font-size:16px">QQ群:546252257<br />

在QQ群里提问前，请先把<a  style="color:blue;font-size:16px" target="_blank" href="http://www.demososo.com/jc.html">官网所有教程</a>看完。
</span>


</div>
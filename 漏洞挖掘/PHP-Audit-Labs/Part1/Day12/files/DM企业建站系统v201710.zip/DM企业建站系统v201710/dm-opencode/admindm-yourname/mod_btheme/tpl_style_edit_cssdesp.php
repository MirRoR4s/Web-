<?php
      
  $sql = "SELECT cssdir,sta_sqlcss from ".TABLE_STYLE."  where pidname='$pidname' $andlangbh   order by id limit 1";
$row = getrow($sql);
$cssdir = $row['cssdir'];
$sta_sqlcss = $row['sta_sqlcss'];

$cssfilename = 'template/'.$cssdir .'/css/'.$pidname.'.css';
 $cssfile = STAROOT.'template/'.$cssdir .'/css/'.$pidname.'.css';
  $cssfilebak =  WEB_ROOT.'cache/customcss/'.$pidname.'_bak_'.$bshou.'.css';
if(is_file($cssfile)){ 

if($act=='update'){
   if(@$_POST['inputmust']=='') {echo $inputmusterror.$backlist;exit;}
   //$ss = "update ".TABLE_STYLE." set desp='$abc1' where pidname='$pidname' $andlangbh limit 1";
   // echo $ss;exit;    
  // iquery($ss);  

$despv = $_POST['desp'];

  // $despv=str_replace("[uploadpath]",UPLOADPATHIMAGE,$abc1);

 
        if (!copy($cssfile,$cssfilebak)) {
        echo  '<p style="padding:20px;font-size:16px;color:red">对不起，'.$cssfilename.'备份不成功。failed to copy $cssfile...</p>';
        }
  

file_put_contents($cssfile,$despv);

 $jumpv = $jumpv_pf.'&act=edit';
 jump($jumpv);

}
else{


$desp=file_get_contents($cssfile);  
  
 // $sql = "SELECT * from ".TABLE_STYLE."  where pidname='$pidname' $andlangbh   order by id limit 1";
//$row = getrow($sql);
 

//$desp=$row['desp'];
 $jumpv_insert = $jumpv_pf.'&act=update';

 
   $cssfile2 = 'DM-static/template/'.$cssdir .'/css/'.$pidname.'.css';
   
 $linkcss = STAPATH.'template/'.$cssdir .'/css/'.$pidname.'.css?v='.rand(1000,9999);
 


?>
<h2 class="h2tit_biao" style="margin-bottom:10px">
<a href="<?php echo $jumpv?>"> <返回模板管理</a>  </h2>

<div class="pro_album_left">
<h2 class="h2tit_biao"> 修改样式
</h2>

<?php 
require_once HERE_ROOT.'mod_btheme/tpl_style_inc_css.php';

?>


</div>
<div class="pro_album_right">
<h2 class="h2tit_biao">修改自定义样式</h2>

<p>提示：这里的样式来自 css文件：<a href="<?php echo $linkcss;?>" target="_blank"> <?php echo $cssfile2;?></a>，所以你也可以直接编辑这个css文件。
  <br />这里的内容修改后即生效。 同时会在cache/customcss目录创建一个备份文件。

   
</p>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpv_insert;?>" method="post">
  <table class="formtab">
 


    <tr>
      
      <td> 
   <textarea  style="font-size:16px" name="desp" cols="150" rows="35"><?php echo $desp;?></textarea> 
      </td>
    </tr>
     
        
    
  <tr>
   
      <td>
      <input  class="mysubmitnew" type="submit" name="Submit" value="提交" /></td>
    </tr>
    </table>
    <?php 
     //<p class="hintbox">使用上传的图片的方法：[uploadpath]1/****.jpg</p>
?>
    <?php echo $inputmust;?>
    
</form>
 
<?php
 }
}
else  {

  file_put_contents($cssfile,'');//初始化下cssfile.如果不存在，会自动创建。
  //echo '文件不存在'.$cssfilename.',请先创建这个css文件。';
  jump($jumpv_pf2);

}
?>

</div>
<div class="c"></div>

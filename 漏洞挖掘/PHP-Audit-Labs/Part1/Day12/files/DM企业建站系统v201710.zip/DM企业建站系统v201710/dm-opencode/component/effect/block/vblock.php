
 <?php 
 global $andlangbh;global $curstyle;
    $sqlall="select * from ".TABLE_BLOCK." where pidname='$pidname'   and type='vblock'    $andlangbh  order by id desc limit 1";
  // echo $sqlall;
    if(getnum($sqlall)>0){
        $v = getrow($sqlall);
 
     $tid = $v['id'];//$effect = $v['effect'];
     $name = $v['name'];//$sta_name = $v['sta_name'];
      $cssname = $v['cssname']; $more = $v['more'];
     $blockid = $v['blockid'];$blockcntid = $v['blockcntid'];
     $videotitle = $v['videotitle'];$videoaddress = $v['videoaddress'];
     //$videoimg = $v['videoimg']; videoimg use kv...
       $videoimg = $imgsmall = $v['kv'];
       if($imgsmall=='') {$imgv=$imgv2='';}
       else{
           $imgv = UPLOADPATHIMAGE.$imgsmall; 
          $imgv2 = '<img class="perimgmax100" src="'.$imgv.'" alt="'.$name.'" />'; //use onledesp...

      }

//$morev = $more<>''?$more:TEXTMORE;

$linkurl = $v['linkurl'];  
$linkurlv ='';
$more = $more<>''?$more:'查看详情 >';
if($linkurl<>'')  $linkurlv ='<div class="bkmore dmbtn"><a  '.linktarget($linkurl).' class="more" title="'.$name.'" href="'.$linkurl.'">'.$more.'</a></div>';

    
 
    $despjj = decode($v['despjj']);
    $desp= web_despdecode($v['desp']);
      $desptext= web_despdecode($v['desptext']);
      $despv='';
      if($desptext<>'') $despv = $desptext;
      else  $despv = $desp;

    

 $namev =  is_int(strpos($cssname,'showtitle'))?'<h3>'.$name.'</h3>':'';
  $despjjv =  $despjj<>''?'<div class="despjj">'.$despjj.'</div>':'';

 $despv='<div class="despwrap">'.$namev.$despjjv.'<div class="desp">'.$despv.'</div>'.$linkurlv.'</div>';

  //$effectname = get_fieldnolang(TABLE_BLOCK,'effect',$blockcntid,'pidname');

   //   if($blockid=='' || $blockid =='single_normal')   $blockid2 = 'single_normal_mb'; 
     // else  $blockid2 = $blockid; 
     // echo '<!--effect:'.$blockcntid.'-->'; 
// $arrblockdata=array(
//   'name'=>$name,
//   'cssname'=>$cssname,
//   'imgv'=>$imgv,
//   'despv'=>$despv,
//   );
     if(substr($blockcntid, 0,6)=='bkcnt_'){
      // if($blockcntid<>'bkcnt_onlydesp') blockcnt($blockcntid,$arrblockdata);
     // else echo '<div class="c '.$cssname.'">'.$imgv2.$despv.'</div>';
         if($blockcntid<>'bkcnt_onlydesp')  require EFFECTROOT.'block/vblock_bkcnt.php';
         else  require EFFECTROOT.'block/vblock_onlydesp.php';
     

    }
     else{ 
       $reqfile=EFFECTROOT.'block/'.$blockcntid.'.php';
       if(is_file($reqfile)) require $reqfile;
       else echo '<p style="background:#ccc;color:red">没有此文件: '.$reqfile.' </p>';
      }


           
}
else { echo '<p>暂无内容，找不到区块： '.$pidname.'</p>';}
?>



<?php
/*
	power by JASON.ZHANG
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}
?>
<?php
define('TABLE_USER', 'zzz_user');
define('TABLE_ALBUM', 'zzz_album');
define('TABLE_BLOCK', 'zzz_block');
define('TABLE_COMMENT', 'zzz_comment');

define('TABLE_REGION', 'zzz_region');
define('TABLE_LAYOUT', 'zzz_layout'); 
 
define('TABLE_IMGFJ', 'zzz_imgfj');

define('TABLE_ALIAS', 'zzz_alias'); 
define('TABLE_CATE', 'zzz_cate');
define('TABLE_LANG', 'zzz_lang');
define('TABLE_MENU', 'zzz_menu');
define('TABLE_PAGE', 'zzz_page');
define('TABLE_NODE', 'zzz_node');
define('TABLE_DDORDER', 'zzz_ddorder');
define('TABLE_DDPRODUCT', 'zzz_ddproduct');

define('TABLE_FIELD', 'zzz_field');
define('TABLE_FIELDOPTION', 'zzz_fieldoption');
define('TABLE_FIELDVALUE', 'zzz_fieldvalue');

define('TABLE_STYLE', 'zzz_style');
?>
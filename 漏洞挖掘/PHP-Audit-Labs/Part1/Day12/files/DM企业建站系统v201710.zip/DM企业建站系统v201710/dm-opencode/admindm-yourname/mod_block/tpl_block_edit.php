<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
 */
if (!defined('IN_DEMOSOSO')) {
    exit('this is wrong page,please back to homepage');
}
if ($act == 'update') {

     if(@$_POST['inputmust']=='') {echo $inputmusterror.$backlist;exit;}


   //  pre($_POST);
   //exit;
//if($abc1==''){echo '对不起，标题或名称不能为空。'.$backlist;exit;}
   $jump_insertimg = $jumpv . '&file=edit&act=edit&tid=' . $tid;

   if($abc1=="") {alert('请输入标题！');  jump($jump_insertimg); }

       $sql = "SELECT kv from ".TABLE_BLOCK." where  type='vblock' and id='$tid' $andlangbh   limit 1";
                           $row = getrow($sql);
                           $imgsqlname =$row['kv'];  
                       
     $delimg = zbdesp_onlyinsert($_POST['delimg']);                            
    if($delimg=='y'){
        if($imgsqlname<>'') p2030_delimg($imgsqlname,'y','y');
        $kv_v = ",kv = ''";
    }
    else{
         $imgname = $_FILES["addr"]["name"];
       $imgsize = $_FILES["addr"]["size"];
       if (!empty($imgname)) {
           //make thumb
          //  $sql = "SELECT sm_w,sm_h from ".TABLE_BLOCK." where pidname='$pidname'  $andlangbh   limit 1";
           //                $row = getrow($sql);
           //                $up_w_s =$row['sm_w'];$up_h_s =$row['sm_h'];   
                        //  echo $up_w_s.'-'.$up_h_s;
          // if( $up_w_s==0 ||  $up_h_s == 0) $up_small = 'n';
           //else $up_small = 'y';  
            
            $up_small = 'n';           
           $imgtype = gl_imgtype($imgname);
          // $up_small = 'y';
           $up_delbig = 'n';//not del,just override
           $up_water = 'n';           
           $i = '';
           require_once('../plugin/upload_img.php'); //need get the return value,then upimg part turn to easy.
           $kv_v = ",kv = '$return_v'";
       }
       else  $kv_v = "";
    
    }

 
 $despjj = zbdespadd2($abc3);	

    $desp = zbdesp_onlyinsert($_POST['despcontent']); //note: desp and addr not use variable abc1.
    $desptext = zbdesp_onlyinsert($_POST['editor1text']);
    //[editor1text] => 
    //  [despcontent] =>     
  // abc6 is delimg select label...
    // videoimg use kv...
   $ss = "update " . TABLE_BLOCK . " set name='$abc1',cssname='$abc2',despjj='$despjj',linkurl='$abc4',more='$abc5' $kv_v,blockid='$abc7',videotitle='$abc8',videoaddress='$abc9',blockcntid='$abc10',desptext='$desptext',desp='$desp',dateedit='$dateall' where type='vblock' and id='$tid' $andlangbh limit 1";
    //echo $ss;exit;

    iquery($ss);
    //alert("修改成功");
    
    
     $jump_insertimg = $jumpv . '&file=edit&act=edit&tid=' . $tid;

    jump($jump_insertimg);
}



if ($act == 'edit') {
    $titleh2 = '修改';
    $sqlsub = "SELECT * from " . TABLE_BLOCK . "  where  type='vblock' and id='$tid' $andlangbh order by id limit 1";
    if(getnum($sqlsub)>0){
    //echo $sqledit;exit;
    $rowsub = getrow($sqlsub);
   // pre($rowsub);
    //$desp=zbdesp_imgpath($row['desp']);
    $kv = $rowsub['kv'];
    $name = $rowsub['name']; 
    // $sta_title = $rowsub['sta_name'];  
      $cssname = $rowsub['cssname'];  $despjj = zbdespedit($rowsub['despjj']);
    $pidnamehere = $rowsub['pidname'];
    $linkurl = $rowsub['linkurl'];$more = $rowsub['more'];
    $blockid = $rowsub['blockid'];
     $blockcntid = $rowsub['blockcntid']; //is effect

     


    $jump_insertimg = $jumpv . '&file=edit&act=update&tid=' . $tid;
    $imgsmall2 = p2030_imgyt($kv, 'y', 'n');


    $videotitle = $rowsub['videotitle'];$videoaddress = $rowsub['videoaddress'];$videoimg = $rowsub['videoimg'];
    

//$despjj = $rowsub['despjj'];
    $desp = zbdesp_imgpath($rowsub['desp']);
    $desptext = zbdesp_imgpath($rowsub['desptext']);
    



?>
<h2 class="h2tit_biao"><?php echo $titleh2; ?> </h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jump_insertimg; ?>" method="post" enctype="multipart/form-data">
    <table class="formtab">
        <tr>
            <td width="12%" class="tr">标题：</td>
            <td width="88%"> 
                <input name="title" type="text"   value="<?php echo $name; ?>" size="90"><?php echo $xz_must; ?>  

    <?php 
 $previewlink = $userurl.'previewofndlist&tov='.$pidnamehere.'='.LANG;
 ?>
  <a   style="color:#666" href="<?php echo $previewlink;?>" target="_blank">预览<i class="fa fa-link"></i></a>
             
            </td>
        </tr>

  
      

         <tr>
            <td width="12%" class="tr">样式名称：</td>
            <td width="88%"> 
                <input name="cssname" type="text"  class="inputcss" value="<?php echo $cssname; ?>" size="60"><?php echo $xz_maybe; ?>
                <p class="cgray">参考： col2_37,col2_73,col2_46,col2_64,moresm,moresm2,moresmw,moresmw2,morenocir,onlytext_p,showtitle </p>  
            </td>
        </tr>
         <tr>
            <td width="12%" class="tr">副标题：</td>
            <td width="88%"> 
                <textarea cols="120" rows="3" name="despjj"><?php echo $despjj; ?></textarea> <?php echo $xz_maybe; ?>                  
            </td>
        </tr>




        <tr>
            <td width="12%" class="tr">更多链接：</td>
            <td width="88%"> 
链接的网址：<input name="linkurl" type="text"  value="<?php echo $linkurl; ?>" size="70"><?php echo $xz_maybe; ?>  

<div class="c5"> </div>

链接的字样：<input name="more" type="text"  value="<?php echo $more; ?>" size="20"><?php echo $xz_maybe; ?> <br /><br />
            </td>
        </tr>
 
     
        
        <tr>
            <td width="12%" class="tr">上传图片：
            <br />
<span class="cgray">也可用于视频封面图片</span>

            </td>
            <td width="88%"> <input name="addr" type="file" id="addr" size="50" /><?php echo $xz_maybe;?>  
<?php
echo '<br /><span class="cred">' . $format_t . '</span><br />';
// echo gl_showsmallimg($fo_bef,$imgsmall,'y');
echo $imgsmall2;
?>
             
          <?php  if($kv<>'') 
			  {
              ?>
				  <span class="cred"> <br />是否要删除图片？ </span>
				  
				  <select name="delimg">
					<?php select_from_arr($arr_yn,'n','');?>
					</select>
          <?php } 
          else{ //use for : Undefined index: delimg 
              ?>          
				 <select name="delimg" style="display:none">
					  <option value=""></option>
				</select>
          <?php
          }?>
                   
            </td>
        </tr>


         <tr>
            <td width="12%" class="tr">标识：</td>
            <td width="88%"> 
 <input name="blockid" type="text"  value="<?php echo $blockid; ?>" size="30"><?php echo $xz_maybe; ?>  
 <span class="cgray">当使用幻灯片等动画效果时，可以添加标识</span>
 <?php 
    if($blockid<>'') echo check_blockid($blockid);
 ?>
   </td>
        </tr>
 

     <tr bgcolor="#DBF2FF">
            <td width="12%" class="tr">视频管理：</td>
            <td width="88%"> 
<br />
视频标题 ：  <input name="videotitle" type="text"  value="<?php echo $videotitle?>" size="80"> <?php echo $xz_maybe;?>
   
<div class="c5"></div>

   视频地址 ： <textarea name="videoaddress" cols="120" rows="5"><?php echo $videoaddress?></textarea><?php echo $xz_maybe;?>

        <?php 
         $videoext = substr($videoaddress, -3);
               if($videoext=='mp4') {
            //http://www.mediaelementjs.com/#installation
           
                     $strpos = strpos($videoaddress,'://');
                     if(!is_int($strpos)){ 
                            $videoaddressloc = STAROOT.'video/'.$videoaddress;
                            
                            if(!is_file($videoaddressloc)) echo '<br /><span class="cred"> DM-static / video目录不存在这个视频文件:'.$videoaddress.'</span>';
                     }
                     
                }

         ?>

  <br />
   <span class="cgray">如果是mp4的视频，不支持IE8
<br />
   如果是网站内部的mp4，则mp4文件必须放在 DM-static / video目录下，然后这里只要输入文件名即可，比如 videoname.mp4
   </span>
 <br />
             <a href="http://www.demososo.com/detail-92.html" target="_blank">查看视频管理的教程</a>

       <br />

     视频封面图片 ： （请在上面上传图片）

   </td>
        </tr>





 


         <tr>
            <td class="tr fb">区块的效果：</td>
            <td>  
          <strong class="cred">上面的选项是否在前台有效，取决于下面选择的效果</strong>
          <br />
  <select name="blockcntid">
                  <?php 
                 // $arr_newblock = array_merge($arr_blockcnt,$arr_singleblock); 
                  select_from_arr($arr_blockcnt,$blockcntid,'');?>
                   </select> 
            </td>
        </tr>

   

        <tr>
            <td class="tr">内容：


            </td>
            <td> 
              
                <p>
                
  
    <!--
    <a href="../mod_imgfj/mod_imgfj.php?pid=<?php //echo $pidnamehere;?>&lang=<?php //echo LANG;?>" target="_blank">私有编辑器附件管理(<?php //echo num_imgfj($pidnamehere);?>)</a>
|
-->

 <a href="../mod_imgfj/mod_imgfj.php?pid=common&lang=<?php echo LANG; ?>" target="_blank">公共编辑器附件管理</a>

                </p>



<?php require_once('../plugin/editor_textarea.php'); //textarea is in this file ?>

            </td> 
        </tr>






        <tr>
            <td></td>
            <td>
                <input  class="mysubmitnew" type="submit" name="Submit" value="<?php echo $titleh2; ?>"></td>
        </tr>
    </table>

      <?php echo $inputmust;?>

</form>

<?php 

} 
else{echo '区块不存在 ';}

}

?>


<script>
    function checkhere(thisForm) {
        if (thisForm.title.value == "")
        {
            alert("请输入标题。");
            thisForm.title.focus();
            return (false);
        }

        // return;

    }


</script>

<?php
/*
	power by JASON.ZHANG  DM建站  www.demososo.com
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}


 if($act=='update'){


//pre($_POST);
 
 
   if(@$_POST['inputmust']=='') {echo $inputmusterror.$backlist;exit;}


  $sql = "SELECT videoimg from ".TABLE_NODE."  where  id='$tid' $andlangbh   order by id limit 1";
$row = getrow($sql);
 
$imgsqlname=$row['videoimg'];




          $delimg = zbdesp_onlyinsert($_POST['delimg']);   

    if($delimg=='y'){
        if($imgsqlname<>'') p2030_delimg($imgsqlname,'y','y');
        $kv_v = ",videoimg = ''";
    }
    else{

         $imgname = $_FILES["addr"]["name"];
       $imgsize = $_FILES["addr"]["size"];
       if (!empty($imgname)) {
           $imgtype = gl_imgtype($imgname);
           $up_small = 'n';
           $up_delbig = 'n';
           $up_water = 'n';           
           $i = '';
           require_once('../plugin/upload_img.php'); //need get the return value,then upimg part turn to easy.
           $kv_v = ",videoimg = '$return_v'";
       }
       else  $kv_v = "";
    
    }




      $videotitle = zbdesp_onlyinsert($_POST['videotitle']); 
      $videoaddress = zbdesp_onlyinsert($_POST['videoaddress']); 

     $ss = "update ".TABLE_NODE." set videotitle='$videotitle',videoaddress='$videoaddress'$kv_v  where id='$tid' $andlangbh limit 1";

	 // echo $ss;exit;
	 	iquery($ss);
  jump($jumpv_file);

 }
 else
 {

  $sta_noaccess=$pagelayout='n';
  $seocus1=$seocus2=$seocus3=$downloadurl=$videourl=$videotitle='';

 
$sql = "SELECT videotitle,videoaddress,videoimg from ".TABLE_NODE."  where  id='$tid' $andlangbh   order by id limit 1";
$row = getrow($sql);
 
$videotitle=$row['videotitle'];     
$videoaddress=$row['videoaddress']; //put last,or override by arr.

$kv=$row['videoimg'];
 $imgsmall2 = p2030_imgyt($kv, 'y', 'n');
 ?>
  <form  action="<?php echo $jumpv_file; ?>&act=update" method="post" enctype="multipart/form-data">

<h2 class="h2tit_biao">视频管理</h2> 
 
  <table class="formtab" >
 

 
 
 
     <tr>
      <td class="tr" width="12%">视频标题 ：</td>
      <td > <input name="videotitle" type="text"  value="<?php echo $videotitle?>" size="80"> <?php echo $xz_maybe;?>
   
       
    
        </td>
    </tr>




     <tr>
      <td class="tr" width="12%">视频地址 ：</td>
        <td ><textarea name="videoaddress" cols="120" rows="5"><?php echo $videoaddress?></textarea><?php echo $xz_maybe;?>

        <?php 
         $videoext = substr($videoaddress, -3);
               if($videoext=='mp4') {
            //http://www.mediaelementjs.com/#installation
           
                     $strpos = strpos($videoaddress,'://');
                     if(!is_int($strpos)){ 
                            $videoaddressloc = STAROOT.'video/'.$videoaddress;
                            
                            if(!is_file($videoaddressloc)) echo '<br /><span class="cred"> DM-static / video目录不存在这个视频文件:'.$videoaddress.'</span>';
                     }
                     
                }

         ?>
   <br />
   <span class="cgray">如果是mp4的视频，不支持IE8
<br />
   如果是网站内部的mp4，则mp4文件必须放在 DM-static / video目录下，然后这里只要输入文件名即可，比如 videoname.mp4
   </span>
   <br />
        <a href="http://www.demososo.com/detail-92.html" target="_blank">查看视频管理的教程</a>

      </td>
    </tr>


 <tr>
      <td class="tr" width="12%">视频封面图片 ：</td>
        <td >

        <input name="addr" type="file"  size="50" /><?php echo $xz_maybe;?>  
<?php
echo '<br /><span class="cred">' . $format_t . '</span><br />';
// echo gl_showsmallimg($fo_bef,$imgsmall,'y');
   if($kv<>'')    echo $imgsmall2;
?>
             
    <?php  if($kv<>'')    {
              ?>
          <span class="cred"> <br />是否要删除图片？ </span> 
          <select name="delimg">
    <?php select_from_arr($arr_yn,'n','');?>
     </select>
          <?php } 
          else{ //use for : Undefined index: delimg 
              ?>          
          <select name="delimg" style="display:none">
              <option value=""></option>
         </select>
          <?php
          }?>
              
              <br /> 

               
      </td>
    </tr>








</table>


    

  

<div class="c tc"> 
 
 <input class="mysubmitnew"     type="submit" name="Submit" value="提交" /> 
     
<?php echo $inputmust;?>
 </div>

 </form>
<?php
  }
  ?>
  
 
<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}
/*这个页面是用来放   在线客服，分享代码，返回顶部等  悬浮在网页上。*/
?>
<?php  
 block($bsfooterlast);
 ?>



 
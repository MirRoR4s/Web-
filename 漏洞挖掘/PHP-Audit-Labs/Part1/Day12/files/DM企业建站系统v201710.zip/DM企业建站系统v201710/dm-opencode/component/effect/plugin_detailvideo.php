    <?php 
       $videoext = substr($videoaddress, -3);
       ?>

     <div class="videodetail">
         <div class="videodesp"  <?php if($videoext=='mp4'){echo 'style="height:auto"';}?>>
         <?php 
      
        
         if($videoext=='mp4') {
            //http://www.mediaelementjs.com/#installation

           


           
                     $strpos = strpos($videoaddress,'://');
                     if(is_int($strpos)){ 
                            $videoaddressloc = $videoaddress;
                     }
                     else $videoaddressloc = STAPATH.'video/'.$videoaddress;

             
            //video image
            if($videoimg=='') $videoimgv = STAPATH.'img/video.jpg';
            else  $videoimgv = UPLOADPATHIMAGE.$videoimg;
            ?>


 <div class="media-wrapper">
                <video id="player1" width="100%" height="100%" style="max-width:100%;" poster="<?php echo $videoimgv;?>" preload="none">
                    <source src="<?php echo $videoaddressloc;?>" type="video/mp4"> 
                </video>
            </div>



            <?php
         }
         else echo decode($videoaddress);
     ?>
        </div>
        <?php if($videotitle<>'') echo '<div class="videotitle">'.$videotitle.'</div>';?>
        
    </div>

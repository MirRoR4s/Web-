<?php
/*  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
require_once '../config_a/common.inc2010.php';

ifhave_lang(LANG);//TEST if have lang,if no ,then jump

 
if($pidname<>'') {ifhaspidname(TABLE_REGION,$pidname);}
 

if($pid<>'') {ifhasrecord(TABLE_REGION,$pid,'pidname','no pid');}
else{echo 'need pid';exit;}

if(is_numeric($tid)) {   ifhasid(TABLE_REGION,$tid);}




 if($act <> "pos") zb_insert($_POST);



if($file=='') $file='list';
$filearr =  array("list", "addedit");  
if(!in_array($file,$filearr))   {echo 'file is error.';exit;}

$title = '组合区块管理'; 
 
$type='comsub';
 
 
 

$jumpv='mod_regcommon.php?lang='.LANG.'&pid='.$pid;
 
$jumpvf=$jumpv.'&file='.$file;
$jumpvp=$jumpv.'&pidname='.$pidname;
$jumpvpf=$jumpvf.'&pidname='.$pidname;


//------------------
 
    $nameparent = get_field(TABLE_REGION,'name',$pid,'pidname');
    $title = '组合区块管理 --> '.$nameparent;

   // if($file=='list') $title=$title.' - <a style="float:none;color:#0066CA" href="mod_mainregion.php?lang='.LANG.'">< 返回页面区域</a>';
 
 
//---
if($act == "sta")
{
     $ss = "update ".TABLE_REGION." set sta_visible='$v' where id=$tid $andlangbh limit 1";
  // echo $ss;exit;
    iquery($ss);
    jump($jumpv); 
}

//-------------
if($act == "pos")
{
    foreach ($_POST as $k=>$v){
         $ss = "update ".TABLE_REGION." set  pos='$v' where id='$k' and pid='$pid'  $andlangbh  limit 1";
         iquery($ss);
        }
      jump($jumpv);
}

 
 

if($act == "delsub")
{ 
  ifsuredel(TABLE_REGION,$pidname2,$jumpv);
  
}



//-----------
 
  require_once HERE_ROOT.'mod_common/tpl_header.php'; 
 
  require_once HERE_ROOT.'mod_regcommon/tpl_regcommon_'.$file.'.php';
 
require_once HERE_ROOT.'mod_common/tpl_footer.php';
 
?>
 <div class="tabs_wrapper tabs_echocontent tabs_content1">
                       

    <div class="tabs_switch tabs_switchcss">
        <div  class="tabs_item active">酒店</div>
        <div  class="tabs_item">吧台</div>
        <div   class="tabs_item ">接送</div>
        <div   class="tabs_item ">游泳池</div>
    </div>


  <div class="tabs_content">

        <div class="tabs_container">                             
            <div class="c col2 bkcntbox">
                   <div class="w1">
                        <img class="perimg100" src="<?php echo CSSPATH?>images/tab_img_1.jpg" alt="" />
                  </div>

                  <div class="w2">
                      <div class="bkdesp">
                          <h3>酒店</h3>
                         
                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。</p>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。</p>

                    </div>
                  </div>
                 
            </div>                               

       </div>


          <div class="tabs_container" style="display:none">                             
            <div class="c col2 bkcntbox">
                  <div class="w1">
                     <img class="perimg100" src="<?php echo CSSPATH?>images/tab_img_2.jpg" alt="" />
                  </div>
                  <div class="w2 ">
                         <div class="bkdesp">
                          <h3>接送</h3>
                          
                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。</p>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。</p>

                    </div>
                  </div>
            </div>                               

       </div>


               <div class="tabs_container">                             
            <div class="c col2 bkcntbox">

                  <div class="w1">
                        <img class="perimg100" src="<?php echo CSSPATH?>images/tab_img_3.jpg" alt="" />
                  </div>

                  <div class="w2">
                      <div class="bkdesp">
                         <h3>游泳池</h3>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。</p>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。</p>

                    </div>
                  </div>
                  
            </div>                               

       </div>


               <div class="tabs_container">                             
            <div class="c col2 bkcntbox">
                  <div class="w1">
                      <img class="perimg100" src="<?php echo CSSPATH?>images/tab_img_4.jpg" alt="" />
                  </div>
                  <div class="w2 ">
                        <div class="bkdesp">
                         <h3>吧台</h3>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。</p>

                          <p>DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。DM建站系统，集pc，手机，微信于一体。。。<br>
                          DM建站系统，集pc，手机，微信于一体。。。</p>

                    </div>
                  </div>
            </div>                               

       </div>




             
  </div><!--end tab_content-->

   </div>
 
 
 
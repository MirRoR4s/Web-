				
<div class="diviso">
<ul class="diviso_filter">
<li><a href="#" data-filter="*" class="active">所有</a></li>

<?php global $andlangbh;
	$sql = "SELECT * from ".TABLE_CATE." where pid='cate20151227_1226237061' $andlangbh order by pos desc,id";	 
					if(getnum($sql)>0){
							$rowall = getall($sql);	
						 
							foreach($rowall as $v){
								$name = decode($v['name']);	$pidname = $v['pidname'];
								?>
							<li><a href="#" data-filter=".<?php echo $pidname?>"><?php echo $name?></a></li>	
								<?php
							}

				}
  ?>


</ul>
 

<ul class="gridlistiso diviso_items_team">


 
<?php 
	$sql = "SELECT * from ".TABLE_NODE." where ppid='cate20151227_1226237061' $andlangbh order by pos desc,id desc";	 
	if(getnum($sql)>0){
				$rowall = getall($sql);	
				foreach($rowall as $v){
					$tid=$v['id'];
					$pid=$v['pid'];								 
 				$level  =  get_field(TABLE_CATE,'level',$pid,'pidname');
 
				if($level==1) $filter = $pid;
				else {
					$pidhere  =  get_field(TABLE_CATE,'pid',$pid,'pidname');
					$filter = $pidhere;
				}

			$title=$v['title'];
			$titlecss=$v['titlecss'];
			$pidname=$v['pidname'];
			$dateday=$v['dateday'];//echo $listdate;
			$alias=alias($pidname,'node'); 
            $kvsm=$v['kvsm'];

        $desp=web_despdecode($v['desp']);
		$desptext=web_despdecode($v['desptext']);		
		$despv='';
		if($desptext<>'') $despv = $desptext;
		else  $despv = $desp;

		
		 if($kvsm=='') $imgv = DEFAULTIMG;
         else $imgv =  get_thumb($kvsm,$title,'nodiv');

            $url = url('node',$alias,$tid,'');
 
?>
							 	
<li class="<?php echo $filter;?> ">

<div class="img" href="<?php echo $url?>" ><img class="cirshadow" src="<?php echo $imgv?>"   alt="<?php echo $title?>"  /></div>
<div class="title" href="<?php echo $url?>" ><?php echo $title?></div>
<div class="desp" style="display:none"><?php echo $despv?></div>
</li>
 
<?php
	}

 }
 else {echo '暂无内容';}

?>  


</ul> 
</div><!--end diviso-->                                

<div id="teampop" class="popbox"></div>
<style>
 /*.isotope-item
.isotope-item{z-index:2}
.isotope-hidden.isotope-item{pointer-events:none;z-index:1}
.isotope,.isotope .isotope-item{-webkit-transition-duration:0.8s;-moz-transition-duration:0.8s;-ms-transition-duration:0.8s;-o-transition-duration:0.8s;transition-duration:0.8s}
.isotope{-webkit-transition-property:height,width;-moz-transition-property:height,width;-ms-transition-property:height,width;-o-transition-property:height,width;transition-property:height,width}
.isotope .isotope-item{-webkit-transition-property:-webkit-transform,opacity;-moz-transition-property:-moz-transform,opacity;-ms-transition-property:-ms-transform,opacity;-o-transition-property:-o-transform,opacity;transition-property:transform,opacity}
.isotope.no-transition,.isotope.no-transition .isotope-item,.isotope .isotope-item.no-transition{-webkit-transition-duration:0s;-moz-transition-duration:0s;-ms-transition-duration:0s;-o-transition-duration:0s;transition-duration:0s}
.isotope-item{z-index:2}
.isotope-hidden.isotope-item{pointer-events:none;z-index:1}*/
</style>

<script>
$(window).load(function() {
						  
	// cache container
var diviso_items = $('.gridlistiso');
// initialize isotope
diviso_items.isotope({
  itemSelector : '.gridlistiso>li',
  layoutMode : 'fitRows'
});

// filter items when filter link is clicked
$('.diviso_filter a').click(function(){
	$('.diviso_filter a').removeClass('active');
	$(this).addClass('active');
  var selector = $(this).attr('data-filter');
  diviso_items.isotope({ filter: selector });
  return false;
});




}); //end window load

$(function(){
   $('.gridlistiso .img').click(function(){
   	     var img = $(this).html();
   	     var title = '<div class="title">'+$(this).parent().find('.title').html()+'</div>';
   	     var desp = '<div class="desp">'+$(this).parent().find('.desp').html()+'</div>';
   	     var htmltext = '<div class="fl col40 tc">'+img+'</div><div class="fl col60">'+title+desp+'</div>';
   			 $('#teampop').html(htmltext);
         $.fancybox.open("#teampop");
   	     
   });

});

</script>

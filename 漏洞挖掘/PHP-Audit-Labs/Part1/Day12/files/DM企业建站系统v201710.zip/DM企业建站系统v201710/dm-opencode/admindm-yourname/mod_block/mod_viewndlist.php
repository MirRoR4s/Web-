<?php
/*	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
 
require_once '../config_a/common.inc2010.php';
//
 


 if($pidname<>'') {
    if(substr($pidname, 0,6)<>'effect') {echo 'error pidname.must begin with effect'; exit;}

ifhaspidname(TABLE_BLOCK,$pidname);}



$eff = get_fieldarr(TABLE_BLOCK,$pidname,'pidname');
$title = $eff['name'].'   | 文件名：'.$eff['effect'];

//-----------

require_once HERE_ROOT.'mod_common/tpl_header_popup.php'; 
 
 

$sql22 = "SELECT * from ".TABLE_BLOCK." where  type='nd' and effect='$pidname'   order by id desc";
//echo $sql22.'<br>';
$ndnum = getnum($sql22);
if($ndnum>0){

$ndall = getall($sql22);

?>



<div class="nodelistgird gridimghover">

<ul>
<?php
 
 $jumpv='mod_nodelist.php?lang='.LANG;

foreach($ndall as $vcat){
   $tid=$vcat['id']; //tidmain ,not use tid,for conflict in subedit.php
   $name=$vcat['name']; 
   $pidnamecur=$vcat['pidname'];  
   $effect=$vcat['effect'];$typeadmin=$vcat['typeadmin'];
 
 $kv=$vcat['kv'];
 //$imgsmall2 = p2030_imgyt($kv, 'y', 'n');
$kv = '<img src='.get_img($kv, '', '').' alt="" width="150" height="150" />';


 //  $namev = '<a '.$curclass.' href="'.$jumpv.'&pidname='.$pidnamecur.'&file=sublist&act=list">'.$name.'</a>'.$sta_visiblev;
  $editv = '<a class="but1" target="_blank" href="'.$jumpv.'&pidname='.$pidnamecur.'&file=addedit&act=edit">修改</a>   ';
  //$selectmb = '<a class="but1" target="_blank" href="mod_selecteffect.php?pidname='.$pidnamecur.'&lang='.LANG.'">选择效果</a>';
 
  $previewlink = $userurl.'previewofndlist&tov='.$pidnamecur.'='.LANG;
 
 ?>

<li class="<?php echo $typeadmin;?> ">
<div class="img">
<?php 
echo '<a href="'.$previewlink.'" title="预览"  target="_blank">';
  echo $kv;
 echo '</a>';
?>
</div>
<h3  style="height:30px;overflow:hidden;padding:3px 0;font-size:12px;"><?php echo $name;?></h3>

<div style="height:20px;color:#999">
<?php //、echo '效果：'.select_return_string($arr_blocknd,0,'',$effect);
$effectfile= get_field(TABLE_BLOCK,'effect',$effect,'pidname');
echo '效果：'.$effectfile;
//echo '效果：'.$effect;
?>
</div>
 
<div class="cgray" style="padding:5px 0;color:#FF6600">标识： <?php echo $pidnamecur;?></div>



<!--
<div style="height:30px">
 排序号：<input type="text" name="<vhp //echo $tid;?>"  value="<vhp //echo $vcat['pos'];?>" size="5" />
  </div>
-->
<div class="edit"  style="height:30px">
 <?php   echo $editv ;   ?>
</div>
 

</li>


<?php 
    }  //end foreach
 
?>
</ul>
<div class="c"></div>
</div>

<?php

}
else {echo 'no result';exit;}














 require_once HERE_ROOT.'mod_common/tpl_footerpop.php';

?>
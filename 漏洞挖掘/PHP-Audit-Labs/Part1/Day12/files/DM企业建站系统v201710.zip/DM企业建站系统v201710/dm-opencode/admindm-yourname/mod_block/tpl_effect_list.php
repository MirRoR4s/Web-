<div class="menu">
<!-- &nbsp;&nbsp;后台模板编号: -->
<?php //、echo $curstyledebug.' -- '.get_field(TABLE_STYLE,'title',$curstyledebug,'pidname')?>

 <?php 
//$jumpvsel = 'mod_effect.php?lang='.LANG.'&';
//if($stylebh=='') $stylebh = $curstylebh; //move to mod.php
?>
<!-- &nbsp;&nbsp;选择样式编号:
<select name="sellang" onchange="gosele(this,'stylebh','<?php //echo $jumpvsel;?>')">
  -->
  <?php //sele_stylebh($arr_stylebh,$stylebh);?>

<!-- </select>

 -->

</div>
 
 

 <h2 class="h2tit_biao">列表管理 
<a href="<?php echo $jumpv?>&file=addedit&act=add">添加> </a>

 </h2>

 
<form method=post action="<?php echo $jumpv;?>&act=pos">
<table class="formtab">
<tr><td width="60">排序</td>
<td width="190">标识</td>
<td width="350">标题</td>
<td width="300">文件名</td>
<td width="300">查看效果区块</td>
<td width="160">操作</td>
<td>状态</td></tr>

<?php
foreach($arr_blocknd_type as $k=>$v){

 echo '<tr><td colspan="7"  style="background:#669cd1;color:#fff;font-weight:bold;font-size:14px;text-align:center">'.$v.'</td></tr>';

$sql = "SELECT * from ".TABLE_BLOCK." where  type='effect' and typeadmin='$k'   order by pos desc,pidname desc,id desc";
//$noandlangbh  and
// echo $sql;
$rownum = getnum($sql);
if($rownum>0) {

$rowlist = getall($sql);
foreach($rowlist as $vcat){
   $tid=$vcat['id']; $name=$vcat['name']; $effect=$vcat['effect']; $desp=$vcat['desp']; 
   $pidnamecur=$vcat['pidname']; 
//if($pidname==$pidnamecur) $curclass=' style="color:#fff;background:red;padding:3px;" ';
//else $curclass=' ';

 $sta_visible=$vcat['sta_visible']; 
 
 $edit_text= '<a class="but1" href="'.$jumpv.'&file=addedit&act=edit&tid='.$tid.'">修改</a>';
 $imgsmall ='';
//$del_text= "<a href=javascript:delimg('delimg','$tid','$imgsmall','$jumpvt')  class='but2'>删除</a>";
   $del_text= " <a href=javascript:del('deleffect','$pidnamecur','$jumpv')  class=but2>删除</a>";
 // del(actgo2,pidname,backpage){ 
 menu_changesta($sta_visible,$jumpv,$tid,'sta_effect');
  
 

$sql22 = "SELECT id from ".TABLE_BLOCK." where  type='nd' and effect='$pidnamecur'   order by id";
//echo $sql22.'<br>';
$ndnum = getnum($sql22);
 $view_text= '<a class="but1 needpopup" href="mod_viewndlist.php?pidname='.$pidnamecur.'&lang='.LANG.'" target="_blank">查看</a>';


// $namev = '<a '.$curclass.' href="'.$jumpv.'&pidname='.$pidnamecur.'&file=addedit&act=edit"><strong>'.$name.'</strong></a>('.$effect.')'.$sta_visiblev;
 ?>
<tr  <?php echo $tr_hide;?>>
<td align="center"><input type="text" name="<?php echo $tid;?>"  value="<?php echo $vcat['pos'];?>" size="5" /></td>
  <td>  <?php   echo $pidnamecur;?></td>
 <td>  <?php   echo $name;?>
<br><span class="cgray"><?php   echo $desp;?></span>

 </td>



  <td>  <?php   echo $effect; 
    $file = EFFECTROOTADMIN.'block/'.$effect.'.php';
              if(!is_file($file)) echo '<br /><span class="cred">文件:当前模板/'.'block/'.$effect.'.php不存在！</span>';
             ?>
 </td>

<td> <?php   echo ' <span class="cred">('.$ndnum.')</span> ';
if($ndnum>0) echo $view_text ;
?>
 </td>


   <td> <?php echo $edit_text;
   if($ndnum==0)  echo ' | '.$del_text;
   ?></td>       
   <td>  <?php   echo $sta_visible;?></td>
</tr>
<?php 
} 

}
else {  echo '<tr><td colspan="7">'.$norr2.'</td></tr>'; }  


//------------------
}//end typeadmin

?>
</table>
<div style="padding-bottom:22px"><input class="mysubmit" type="submit" name="Submit" value="排序" /><?php echo $sort_ads?></div>
</form>
 
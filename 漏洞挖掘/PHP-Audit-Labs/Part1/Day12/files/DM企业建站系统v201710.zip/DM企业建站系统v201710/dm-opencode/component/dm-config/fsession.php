<?php
//session_save_path(SES_ROOT);
//session_save_path("E:\jason---\www\ptemp\ses");



//session_start();
?>
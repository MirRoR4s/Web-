<div class="baidumap">
 <iframe src="baidumap.html" style="width:100%;height:350PX" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" ></iframe>
 </div>


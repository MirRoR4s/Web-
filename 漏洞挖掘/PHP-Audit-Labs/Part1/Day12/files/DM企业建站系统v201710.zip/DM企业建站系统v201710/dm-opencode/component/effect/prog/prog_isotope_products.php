				
<div class="diviso">
<ul class="diviso_filter">
<li><a href="#" data-filter="*" class="active">所有</a></li>

<?php global $andlangbh;
	$sql = "SELECT * from ".TABLE_CATE." where pid='cate20150805_1125344029' and alias_jump='' $andlangbh order by pos desc,id desc";	 
					if(getnum($sql)>0){
							$rowall = getall($sql);	
						 
							foreach($rowall as $v){
								$name = decode($v['name']);	$pidname = $v['pidname'];
								?>
							<li><a href="#" data-filter=".<?php echo $pidname?>"><?php echo $name?></a></li>	
								<?php
							}

				}
  ?>


</ul>
 

<ul class="gridlistiso">


 
<?php 
	$sql = "SELECT * from ".TABLE_NODE." where ppid='cate20150805_1125344029' $andlangbh order by pos desc,id";	 
	if(getnum($sql)>0){
				$rowall = getall($sql);	
				foreach($rowall as $v){
					$tid=$v['id'];
					$pid=$v['pid'];								 
 				$level  =  get_field(TABLE_CATE,'level',$pid,'pidname');
 
				if($level==1) $filter = $pid;
				else {
					$pidhere  =  get_field(TABLE_CATE,'pid',$pid,'pidname');
					$filter = $pidhere;
				}

			$title=$v['title'];
			$titlecss=$v['titlecss'];
			$pidname=$v['pidname'];
			$dateday=$v['dateday'];//echo $listdate;
			$alias=alias($pidname,'node'); 
            $kvsm=$v['kvsm'];

         if($kvsm=='') $imgv = DEFAULTIMG;
         else $imgv =  get_thumb($kvsm,$title,'nodiv');

            $url = url('node',$alias,$tid,'');
 
?>
							 	
<li class="<?php echo $filter;?> ">

<a class="img" href="<?php echo $url?>" ><img  src="<?php echo $imgv?>"   alt="<?php echo $title?>"  /></a>
<a class="title" href="<?php echo $url?>" ><?php echo $title?></a>

</li>
 
<?php
	}

 }
 else {echo '暂无内容';}

?>  


</ul> 
</div><!--end diviso-->                                

 
 	
<script>
$(window).load(function() {		//must use it,not use ready
	// cache container
var diviso_items = $('.gridlistiso');
// initialize isotope
diviso_items.isotope({
  itemSelector : '.gridlistiso>li',
  layoutMode : 'fitRows'
});

// filter items when filter link is clicked
$('.diviso_filter a').click(function(){
	$('.diviso_filter a').removeClass('active');
	$(this).addClass('active');
  var selector = $(this).attr('data-filter');
  diviso_items.isotope({ filter: selector });
  return false;
});


}); //end window load

</script>
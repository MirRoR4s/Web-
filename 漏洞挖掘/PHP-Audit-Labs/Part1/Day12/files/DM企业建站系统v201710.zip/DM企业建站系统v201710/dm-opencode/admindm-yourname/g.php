<?php
Header("Location: mod_common/login.php");
exit;  
//登录文件在mod_common/login.php
?>

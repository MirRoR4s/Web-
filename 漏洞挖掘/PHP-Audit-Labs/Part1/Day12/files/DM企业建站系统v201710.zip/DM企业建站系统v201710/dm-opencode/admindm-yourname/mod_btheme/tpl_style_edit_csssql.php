<h2 class="h2tit_biao" style="margin-bottom:10px">
<a href="<?php echo $jumpv?>"> <返回模板管理</a> </h2>

<div class="pro_album_left">
<h2 class="h2tit_biao"> 修改样式
</h2>

<?php 
$sta_sqlcss = 'y';
require_once HERE_ROOT.'mod_btheme/tpl_style_inc_css.php';

?>

</div>
<div class="pro_album_right"> 

<h2 class="h2tit_biao">修改数据库样式</h2>

<?php 

  echo '<p>提示：这部分的样式来自数据库(或称为数据库样式)，所以需要点击 生成样式 才能生效。';
echo '<a class="but2" href="'.$jumpv_p.'&file=edit_csssql&&file2=generatecss&act=edit" style="padding:1px 20px">生成样式</a>  </p>';

?>
 
 <?php 
  $editnormal_cur=  $edithf_cur= $editmenu_cur= $editboxtitle_cur='';
   if($file2=='normal') $editnormal_cur = ' cur';
  if($file2=='hf') $edithf_cur = ' cur';
  if($file2=='menu') $editmenu_cur = ' cur';
 if($file2=='boxtitle') $editboxtitle_cur = ' cur';


  echo '<div class="menusub menusub2" style="margin-bottom:20px">';
 $jumpv_psql = $jumpv_p.'&file=edit_csssql';
    echo '<a class="bg22'.$editnormal_cur.'" href="'.$jumpv_psql.'&file2=normal&act=edit"><span  class="bg22" >常用样式</span></a>';
  echo '<a class="bg22'.$edithf_cur.'" href="'.$jumpv_psql.'&file2=hf&act=edit"><span  class="bg22" >页头和页尾样式</span></a>';
 echo '<a class="bg22'.$editmenu_cur.'" href="'.$jumpv_psql.'&file2=menu&act=edit"><span  class="bg22" >菜单样式</span></a>';
  echo '<a class="bg22'.$editboxtitle_cur.'" href="'.$jumpv_psql.'&file2=boxtitle&act=edit"><span  class="bg22" >传统盒子</span></a>';

  echo '</div>';

if($file2 =='') $file2 = 'normal';

require_once HERE_ROOT.'mod_btheme/tpl_style_sql_'.$file2.'.php';
 ?>

</div>
<div class="c"></div>

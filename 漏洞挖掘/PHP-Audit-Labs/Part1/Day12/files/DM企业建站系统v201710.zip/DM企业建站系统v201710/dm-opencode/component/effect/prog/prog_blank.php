<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}
?>

<?php 
/*不要删除这个文件，用于空白内容，do not delete this file,use blank content ,when sidebar or content*/

?>
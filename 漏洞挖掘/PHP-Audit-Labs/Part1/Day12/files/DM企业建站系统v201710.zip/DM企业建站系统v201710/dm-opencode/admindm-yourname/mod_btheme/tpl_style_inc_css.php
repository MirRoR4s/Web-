  <ul>

   <li><a  href="<?php echo $jumpv_p;?>&file=edit_cssdesp&act=edit">修改自定义样式 ></a></li>

   <?php 
 
   if($sta_sqlcss<>'y'){

    ?>
    <li> 您已取消了数据库样式，可以点击下面链接开启它。 </li>

    <?php 
  }
  else {
    ?>
    <li><a href="<?php echo $jumpv_p;?>&file=edit_csssql&act=edit">修改数据库样式 ></a></li>


    <?php 
  }
  ?>

  <li><a href="<?php echo $jumpv_p;?>&file=edit_cssactive&act=edit">开启数据库样式 ></a></li>
</ul>


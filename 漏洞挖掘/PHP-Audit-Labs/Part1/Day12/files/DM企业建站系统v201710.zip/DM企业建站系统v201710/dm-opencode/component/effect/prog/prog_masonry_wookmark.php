
<div id="work-wrapper">
  <div class="container">
      <div class="row-fluid inner-work-wrapper masonrywrap" >
<?php 
 
 global $andlangbh; global $pagesql;global $page;
 global $offset;
 $maxline = 4;//need change in file_masonry.php
 
    $sqllist22 = "SELECT *  from ".TABLE_NODE." where  ppid='cate20150805_1125344029'   and sta_visible='y' and sta_noaccess='n' $andlangbh  order by pos desc,id desc";
  //echo $sqllist22; 
  /*begin page roll*/
     $num_rows = getnum($sqllist22);
      $page_total=ceil($num_rows/$maxline);//must put here,because when no data,we need the vaule of page_total 
     if($num_rows==0){ echo  NOARTICLE;}
     else{ 
        if($page>$page_total) $pagesql=$page_total;
        $start=($pagesql-1)*$maxline;
        $sqllist33="$sqllist22  limit $start,$maxline";
      //ECHO $sqllist33;         
        $result = getall($sqllist33);       
       // pre($result);
    ?>
 <div id="mainwork" role="mainwork">
       <ul id="tiles">
   <?php
 
         foreach($result as $v){
               
                 $tid=$v['id'];
            $title=$v['title'];
            $titlecss=$v['titlecss'];
            $pidname=$v['pidname'];
            
            $alias=alias($pidname,'node'); 
            $kvsm=$v['kvsm'];
            $alias_jump=$v['alias_jump'];
           // $despjj=$v['despjj'];
            
            

      if($kvsm<>'') $imgv =  get_thumb($kvsm,$title,'nodiv');//when grid,first kvsm,then kv,then noimg
      else{   $imgv = DEFAULTIMG;
      }
 


            $url = url('node',$alias,$tid,$alias_jump);

          if($titlecss<>'') $titlecssv='style="'.$titlecss.'"';
          else $titlecssv='';
          
         // $height = rand(90,300);

                echo '<li>';
                echo '<div class="img"><a '.linktarget($url).' href="'.$url.'" '.$titlecssv.'><img src="'.$imgv.'"   alt="'.$title.'" /></a></div>';
                echo '<div class="title"><a '.linktarget($url).' href="'.$url.'" '.$titlecssv.'>'.$title.'</a></div>';
            
                echo '</li>'; 
            }//end foreach
 
?>
</ul></div>
<?php
//echo '<div class="pageroll dn"><a class="next" href="masonry-page.php?page=1"></a></div>';
 
}
 
?>
  <div class="loading" style="padding:20px;text-align:center;display:none"></div>
  <div style="height:100px"> </div>


</div>
</div>
</div>

<style type="text/css">
#mainwookmark {  margin: 30px 0;  position: relative;}
#tiles{list-style-type:none;position:relative;margin:0;padding:0}
#tiles li{width:250px;background-color:#ffffff;border:1px solid #dedede;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;display:none;cursor:pointer;padding:4px}
#tiles li.inactive{visibility:hidden;opacity:0}
#tiles li img{display:block;width:100%;height: auto}
#tiles li p{color:#666;font-size:13px;line-height:20px;text-align:center;font-weight:200;margin:7px 0 2px 7px}
</style>

<!--not need  app/jquery.imagesloaded.js -->
<script type="text/javascript" src="<?php echo STAPATH?>app/jquery.wookmark.js"></script>
  

  <script type="text/javascript">
    (function ($){
      var $tiles = $('#tiles'),
          $handler = $('li', $tiles),
          $main = $('#mainwork'),   
          page = 2,      pagetotal = <?php echo $page_total?>,      
          apiURL = 'dmpostform.php?type=wookmark',
          $window = $(window),
          $document = $(document),
          options = {
            autoResize: true, // This will auto-update the layout when the browser window is resized.
            container: $main, // Optional, used for some extra CSS styling
            offset: 20, // Optional, the distance between grid items
            itemWidth: 360 // Optional, the width of a grid item
          };

      /**
       * Reinitializes the wookmark handler after all images have loaded
       */
      function applyLayout() {
        $tiles.imagesLoaded(function() {
          // Destroy the old handler
          if ($handler.wookmarkInstance) {
            $handler.wookmarkInstance.clear();
          }

          // Create a new layout handler.
          $handler = $('li', $tiles);
          $handler.wookmark(options);
        });
      }

      /**
       * When scrolled all the way to the bottom, add more tiles
       */
      function onScroll() {
        // Check if we're within 100 pixels of the bottom edge of the broser window.
        var winHeight = window.innerHeight ? window.innerHeight : $window.height(), // iphone fix
            closeToBottom = ($window.scrollTop() + winHeight > $document.height() - 100);
//console.log(closeToBottom);
        if (closeToBottom) {
          $('.loading').show();
          // Get the first then items from the grid, clone them, and add them to the bottom of the grid
       //   var $items = $('li', $tiles),
             // $firstTen = $items.slice(0, 10);
         // $tiles.append($firstTen.clone());
 //console.log('closeToBottom:'+closeToBottom);
 //console.log('pagetotal:'+pagetotal);
 //console.log('page:'+page);
if(pagetotal>=page){


      $.ajax({
          url: apiURL,
          dataType: 'text', // Set to jsonp if you use a server on a different domain and change it's setting accordingly
          data: {page: page}, // Page parameter to make sure we load new data
          success: function(data){ 
              //alert(data);
              $tiles.append(data); 
             applyLayout();}
        });

}
else {$('.loading').hide();}

  page++;
        
        }
      };





      // Call the layout function for the first time
      applyLayout();

      // Capture scroll event.
      $window.bind('scroll.wookmark', onScroll);
    })(jQuery);
  </script>
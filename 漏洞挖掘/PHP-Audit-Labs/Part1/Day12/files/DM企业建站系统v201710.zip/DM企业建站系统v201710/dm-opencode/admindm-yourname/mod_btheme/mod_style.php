<?php
/*	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
require_once '../config_a/common.inc2010.php';
//
 if($act <> "pos") zb_insert($_POST);
 
 if($pidname<>'') {
  ifhaspidname(TABLE_STYLE,$pidname);
 
}

 
//ifhaspidname(TABLE_NODE,$pid);
//ifhaspidname(TABLE_CATE,$catpid);
ifhave_lang(LANG);//TEST if have lang,if no ,then jump



$jumpv='mod_style.php?lang='.LANG;
$jumpv_p=$jumpv.'&pidname='.$pidname;
$jumpv_f=$jumpv.'&file='.$file;
$jumpv_pf=$jumpv_p.'&file='.$file;
$jumpv_pf2=$jumpv_p.'&file='.$file.'&file2='.$file2;

//----
$submenu='basic';
$title = '模板管理';

 
 if($act == "pos")
{
    foreach ($_POST as $k=>$v){
         $ss = "update ".TABLE_STYLE." set  pos='$v' where id='$k'  $andlangbh  limit 1";
         iquery($ss);
        }
      jump($jumpv);
}

if($act == "sta")
{ 
     $ss = "update ".TABLE_STYLE." set sta_visible='$v' where id=$tid $andlangbh limit 1";   
     iquery($ss);
    jump($jumpv); 
}



if($act == "del")
{ 
 
$stylearr = get_fieldarr(TABLE_STYLE,$pidname,'pidname');
$cssdir = $stylearr['cssdir'];
$kv = $stylearr['kv'];
 
 
  $cssfile = STAROOT.'template/'.$cssdir .'/css/'.$pidname.'.css';
  $cssfilesql = STAROOT.'template/'.$cssdir .'/css/sql_'.$pidname.'.css';
  $kvimg = UPLOADROOTIMAGE.$kv;
 
  if(is_file($cssfile))  unlink($cssfile);
if(is_file($cssfilesql))  unlink($cssfilesql);
if(is_file($kvimg))  unlink($kvimg);
 
  //temp notdel layout
  $delss = "delete from ".TABLE_LAYOUT." where stylebh='$pidname' $andlangbh";  
  iquery($delss);

   //del style:
  ifsuredel_field(TABLE_STYLE,'pidname',$pidname,'eq',$jumpv);

   
}

//-----------

require_once HERE_ROOT.'mod_common/tpl_header.php'; 
if($file=='') require_once HERE_ROOT.'mod_btheme/tpl_style.php';
else {

 if($file<>'add'){//edit part....
?>
<div class="menu">

<!-- <a href="<?php //echo //$jumpv?>">返回模板管理</a>
 -->
正在编辑的模板： 
<span class="cred"><?php 

echo get_field(TABLE_STYLE,'title',$pidname,'pidname');
echo ' - '.$pidname;
?> </span>

</div>
<?php
 } ?>






<?php

 
require_once HERE_ROOT.'mod_btheme/tpl_style_'.$file.'.php';
 }
require_once HERE_ROOT.'mod_common/tpl_footer.php';

?>

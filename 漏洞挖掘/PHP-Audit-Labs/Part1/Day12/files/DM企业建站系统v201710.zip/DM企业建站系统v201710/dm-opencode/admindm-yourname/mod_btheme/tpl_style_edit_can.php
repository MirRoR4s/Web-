<?php
if($act=='update'){

 if(@$_POST['inputmust']=='') {echo $inputmusterror.$backlist;exit;}


 $jump_back = $jumpv_pf.'&act=edit';

 
    $cssdir = STAROOT.'template/'.$abc2;
      if(!is_dir($cssdir)) {alert('出错，模板目录 '.$abc2.'不存在！');  jump($jump_back); }

    $htmldir = WEB_ROOT.'component/'.$abc3;
      if(!is_dir($htmldir)) {alert('出错，html目录 '.$abc3.'不存在！');  jump($jump_back); }





   $sql = "SELECT kv from ".TABLE_STYLE." where pidname='$pidname'  $andlangbh   limit 1";
                           $row = getrow($sql);
                           $imgsqlname =$row['kv'];  
       
       $delimg = zbdesp_onlyinsert($_POST['delimg']);                            
    if($delimg=='y'){
        if($imgsqlname<>'') p2030_delimg($imgsqlname,'y','y');
        $kv_v = ",kv = ''";
    }
    else{

         $imgname = $_FILES["addr"]["name"];
       $imgsize = $_FILES["addr"]["size"];
       if (!empty($imgname)) {
           $imgtype = gl_imgtype($imgname);
           $up_small = 'n';
           $up_delbig = 'n';
           $up_water = 'n';           
           $i = '';
           require_once('../plugin/upload_img.php'); //need get the return value,then upimg part turn to easy.
           $kv_v = ",kv = '$return_v'";
       }
       else  $kv_v = "";
    
    }




 
  $ss = "update ".TABLE_STYLE." set title='$abc1',cssdir='$abc2',htmldir='$abc3',pidmenu='$abc4',pidregion='$abc5',sta_bootstrap='$abc6'$kv_v where pidname='$pidname' $andlangbh limit 1";
   //echo $ss;exit;    
   iquery($ss);  


 
  

  
   jump($jump_back);


}
else{
  $sql = "SELECT * from ".TABLE_STYLE."  where  pidname='$pidname' $andlangbh   order by id limit 1";
$row = getrow($sql);
//pre($row);
$title=$row['title'];
$kv=$row['kv']; $sta_bootstrap=$row['sta_bootstrap'];
$pidmenu=$row['pidmenu'];$pidregion=$row['pidregion'];
 //$imgsmall2 = p2030_imgyt($kv, 'y', 'n');
$imgsmall2 = '<img src='.get_img($kv, '', '').' alt=""  height="200" />';

$jumpv_insert = $jumpv_pf.'&act=update';

?>

<h2 class="h2tit_biao">
<?php if($curstyle<>$pidname){?>
<a href="javascript:del('del','<?php echo $pidname;?>','mod_style.php?lang=<?php echo LANG;?>')" class="fr but2">删除</a>
<?php } ?>
<a href="<?php echo $jumpv?>"> <返回模板管理</a> | 
修改模板</h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpv_insert;?>" method="post" enctype="multipart/form-data">
  <table class="formtab">

      <tr>
      <td   class="tr">模板标题：</td>
      <td > <input name="name" type="text"  value="<?php echo $title;?>" size="50" /> </td>
    </tr>

   <tr>
      <td class="tr">模板目录：</td>
      <td> 
      css目录：
      <input  type="text" name="cssdir" value="<?php echo $row['cssdir'];?>" size="25"><?php echo $xz_must;?>

      <span class="cgray">(默认为default)</span>
      <br />
        html目录：
      <input  type="text" name="htmldir" value="<?php echo $row['htmldir'];?>" size="25"><?php echo $xz_must;?>

      <span class="cgray">(默认为html_default)</span>

        </td>
    </tr>
 
  
     <tr>
      <td   class="tr">选择菜单：</td>
      <td >
      <select name="selemenu">
         <option value="">请选择</option>
          <?php 
   $sqltextlist = "SELECT * from ".TABLE_MENU." where   $noandlangbh and ppid='0'  and sta_visible='y'   order by pos desc, id "; 
   
     $res = getall($sqltextlist);
   foreach($res as $v){
    $pidname = $v['pidname'];
    if($pidname == $pidmenu) $selected = ' selected ';
    else  $selected = '';
     echo '<option '.$selected.' value="'.$pidname.'">'.$v['name'].'</option>';
     
   }
     
     ?>
     </select>   
      </td>
    </tr>

  
     <tr>
      <td   class="tr">选择首页的内容：</td>
      <td >
      <select name="selereg">
         <option value="">请选择</option>
          <?php 
   $sqltextlist = "SELECT * from ".TABLE_REGION." where   $noandlangbh and  pid='0' and type='index'  order by pos desc, id "; 
   
     $res = getall($sqltextlist);
   foreach($res as $v){
    $pidname = $v['pidname'];
    if($pidname == $pidregion) $selected = ' selected ';
    else  $selected = '';
     echo '<option '.$selected.' value="'.$pidname.'">'.$v['name'].'</option>';
     
   }
     
     ?>
     </select>   
      </td>
    </tr>


    <tr>
      <td   class="tr">是否引入bootstrap库：</td>
      <td >
      <select name="sta_bootstrap"> 
        <?php select_from_arr($arr_yn,$sta_bootstrap,'');?>
     </select>   
     <br />
     <span class="cgray">默认不引入。</span>
      </td>
    </tr>



    <tr>
            <td width="12%" class="tr">图片：</td>
            <td width="88%"> <input name="addr" type="file" id="addr" size="50" /><?php echo $xz_maybe;?>  
<?php
echo '<br /><span class="cred">' . $format_t . '</span><br />';
// echo gl_showsmallimg($fo_bef,$imgsmall,'y');
   if($kv<>'')    echo $imgsmall2;
?>
             
    <?php  if($kv<>'')    {
              ?>
          <span class="cred"> <br />是否要删除图片？ </span> 
          <select name="delimg">
    <?php select_from_arr($arr_yn,'n','');?>
     </select>
          <?php } 
          else{ //use for : Undefined index: delimg 
              ?>          
          <select name="delimg" style="display:none">
              <option value=""></option>
     </select>
          <?php
          }?>
              
              <br />  <br />  
</td></tr>


    
  <tr>
      <td></td>
      <td>
      <input  class="mysubmitnew" type="submit" name="Submit" value="提交" /></td>
    </tr>
    </table>
<?php echo $inputmust;?>

</form>
<?php }
?>
<script>
function checkhere(thisForm) {
   if (thisForm.name.value=="")
  {
    alert("请输入标题。");
    thisForm.name.focus();
    return (false);
  } 
     if (thisForm.cssdir.value=="")
  {
    alert("请输入样式css目录。");
    thisForm.cssdir.focus();
    return (false);
  } 
     if (thisForm.htmldir.value=="")
  {
    alert("请输入html目录。");
    thisForm.htmldir.focus();
    return (false);
  } 

   if (thisForm.selemenu.value=="")
  {
    alert("请选择菜单。");
    thisForm.selemenu.focus();
    return (false);
  } 

   if (thisForm.selereg.value=="")
  {
    alert("请选择页面区域。");
    thisForm.selereg.focus();
    return (false);
  } 



}

</script>

<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}

 if($act=='insert')
 {
    if ($abc1 == '')   $abc1 = '请输入标题';  
      $pidname='style'.$bshou;
     //  $pidnamereg='regionindex'.$bshou;

 //arrblockid is in config.php

    //   echo $abc2;
$sourcepidname = $abc2;
    $stylearr = get_fieldarr(TABLE_STYLE,$sourcepidname,'pidname');   
  //pre($stylearr);
 
    $style_normal = $stylearr['style_normal'];
    $style_hf = $stylearr['style_hf'];
    $style_menu = $stylearr['style_menu'];
    $style_boxtitle = $stylearr['style_boxtitle'];
    $style_blockid = $stylearr['style_blockid'];

    $cssdir = $stylearr['cssdir'];
    $htmldir = $stylearr['htmldir'];
    $pidmenu = $stylearr['pidmenu']; $pidregion = $stylearr['pidregion'];

   $ss = "insert into ".TABLE_STYLE." (pidname,pbh,pid,pidmenu,pidregion,title,lang,dateedit,cssdir,htmldir,style_normal,style_hf,style_menu,style_boxtitle,style_blockid) values ('$pidname','$user2510','0','$pidmenu','$pidregion','$abc1','".LANG."','$dateall','$cssdir','$htmldir','$style_normal','$style_hf','$style_menu','$style_boxtitle','$style_blockid')";//pidregion no use
   //echo $ss;exit;
   iquery($ss);

 
 $cssfile = STAROOT.'template/'.$cssdir.'/css/'.$sourcepidname.'.css';
  $cssfilesql = STAROOT.'template/'.$cssdir.'/css/sql_'.$sourcepidname.'.css';

  $des_cssfile = STAROOT.'template/'.$cssdir.'/css/'.$pidname.'.css';
  $des_cssfilesql = STAROOT.'template/'.$cssdir.'/css/sql_'.$pidname.'.css';
 
 //fopen("$cssfile", "w");
  if(is_file($cssfile)) copy($cssfile,$des_cssfile);
  if(is_file($cssfilesql)) copy($cssfilesql,$des_cssfilesql);
 //(!copy($cssfile,$cssfilebak))
 
 
//
   alert("添加成功");
     // jump($jumpv.'&file=edit_normal&pidname='.$pidname);
    jump($jumpv);
    
 }
  
 
 
 
 
 if($act=='add')
 {
   $titleh2 = '添加模板';
 $jumpv_insert = $jumpv_f.'&act=insert';

?>
 
<h2 class="h2tit_biao">
<a href="<?php echo $jumpv?>"> <返回模板管理</a> | 
<?php echo $titleh2?></h2>
<form  onsubmit="javascript:return checkhere(this)" action="<?php echo $jumpv_insert;?>" method="post"  enctype="multipart/form-data">
  <table class="formtab">
    <tr>
      <td width="12%" class="tr">模板的标题：</td>
      <td width="88%"> <input name="name" type="text"  value="<?php echo $name;?>" size="50">
      <?php echo $xz_must?>
 
   </td>
   </tr> 

   <tr>
      <td width="12%" class="tr">选择一个模板：</td>
      <td width="88%">


            <?php
            $sql = "SELECT * from ".TABLE_STYLE."  where $noandlangbh order by pos desc,pidname desc,id desc";
            ?>             
              <select name="selectmb">
<option value="">请选择模板 </option>
            <?php
            $rowlist = getall($sql);
            foreach($rowlist as $v){
              $title=$v['title'];     
              $pidname=$v['pidname'];           
             ?>
             
            <option value="<?php echo $pidname;?>"> <?php echo $title?> </option>
             
            <?php 
            } 
            ?>
             </select>
             
          
      <?php echo $xz_must?>

      <p style="color:#666">
      新添加的模板，会复制上面选择了的模板的样式。
      </p>
   </td>
   </tr> 

 



  <tr>
      <td></td>
      <td>
      <input  class="mysubmit" type="submit" name="Submit" value="<?php echo $titleh2?>"></td>
    </tr>
    </table>
</form>
 

<?php
}
?>

<script>
function checkhere(thisForm) {
   if (thisForm.name.value=="")
  {
    alert("请输入标题");
    thisForm.name.focus();
    return (false);
  } 
    if (thisForm.selectmb.value=="")
  {
    alert("请选择模板");
    thisForm.selectmb.focus();
    return (false);
  } 


}

</script>

Loading iframe url ... <img src="../cssjs/img/loading.gif" />
<?php 
//defualt popup url
?>
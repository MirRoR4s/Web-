<?php
/*	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
 
require_once '../config_a/common.inc2010.php';
//
 if($act <> "pos") zb_insert($_POST);
 
 if($pidname<>'') {
    if(substr($pidname, 0,6)<>'effect') {echo 'error pidname.must begin with effect'; exit;}

ifhaspidname(TABLE_BLOCK,$pidname);}
 
//ifhaspidname(TABLE_NODE,$pid);
//ifhaspidname(TABLE_CATE,$catpid);
ifhave_lang(LANG);//TEST if have lang,if no ,then jump

$effecttypearr = array('vblockccc','dhccc','nd');
$effectfilearr = array(
  //'vblock'=>'图文区块vblock',
   // 'dh'=>'效果区块',
    'nd'=>'效果区块',
    );
if($type=='') $type='nd';


 if (!in_array($type, $effecttypearr)){ echo 'error type.';exit;}

//$effecttype = 'effect_'.$type;
 $effecttype = 'effect_nd';


// if($tid==''){ //when edit .
//         if($stylebh=='') $stylebh = $curstylebh;
// }
// else $stylebh = get_field(TABLE_BLOCK,'stylebh',$tid,'id');

 

$jumpv='mod_effect.php?lang='.LANG;
$jumpvp=$jumpv.'&pidname='.$pidname;
$jumpvf=$jumpv.'&file='.$file;
$jumpvpf=$jumpvp.'&file='.$file;
//$jumpvft=$jumpvf.'&file='.$file.'&type='.$type.'&tid='.$tid;//no pidname
 

//----
$submenu='block';
$title = '效果模板文件管理 ';

//---
if($act == "pos")
{
    foreach ($_POST as $k=>$v){
         $ss = "update ".TABLE_BLOCK." set  pos='$v' where id='$k'  $andlangbh  limit 1";
         iquery($ss);
        }
       jump($jumpv);
}

if($act == "sta_effect")
{ 
     $ss = "update ".TABLE_BLOCK." set sta_visible='$v' where id=$tid $andlangbh limit 1";   
     iquery($ss);
    jump($jumpv); 
}



if($act == "deleffect")
{     
 $sql = "SELECT * from ".TABLE_BLOCK."  where effect='$pidname'  $andlangbh order by id limit 1";
   //echo $sqledit;exit;
    $row  = getrow($sql);
    if($row<>'no'){      
        alert('有区块用到了这个效果文件。请先删除区块。');

        //?lang=cn&pidname=effect20160408_0652381277&file=addedit&act=edit

        jump($jumpv);
        
    }
    

     ifsuredel_field(TABLE_BLOCK,'pidname',$pidname,'eq',$jumpv);

   //   $sql = "SELECT * from ".TABLE_BLOCK."  where pidname='$pidname'   $andlangbh order by id limit 1";
   // //echo $sqledit;exit;
   //  $row  = getrow($sql);
   //  if($row<>'no'){  
   //      $imgsqlname = $row['kv'];
   //       if($imgsqlname<>'')  p2030_delimg($imgsqlname,'y','y');     
   //      ifsuredel_field(TABLE_BLOCK,'pidname',$pidname,'eq',$jumpv);
        
   //  }
    
 
 
}

//-----------

require_once HERE_ROOT.'mod_common/tpl_header_popup.php'; 
require_once HERE_ROOT.'mod_block/tpl_effect.php'; 
 require_once HERE_ROOT.'mod_common/tpl_footerpop.php';

?>
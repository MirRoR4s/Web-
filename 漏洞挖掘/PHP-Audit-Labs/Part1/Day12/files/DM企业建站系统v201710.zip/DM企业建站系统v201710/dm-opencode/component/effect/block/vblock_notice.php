<?php //parent is single_normal.php ?>
<div class="homenotice">
  <a class="cnt popup" href="#homenoticedesp"><?php echo $name?>
  </a>
  <div class="desp" style="display:none"><div id="homenoticedesp" class="popcontentfancy"><?php echo $despv?></div></div>
</div>
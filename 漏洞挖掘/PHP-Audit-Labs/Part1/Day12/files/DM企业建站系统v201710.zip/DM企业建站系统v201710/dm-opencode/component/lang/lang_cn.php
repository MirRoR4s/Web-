<?php
/*
	欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
	exit('this is wrong page,please back to homepage');
}
?>
<?php 
define('BREADLOC','当前位置：');
 define('HOME','首页');
 define('NOARTICLE','对不起，暂无内容');
  define('TEXTMORE','更多>>');

//---some id
  define('LANGID_404','vblock20160510_1000376089');

 define('LANGID_HEADERTOP','region20151217_1144369667');
  define('LANGID_HEADER','region20150726_0620266453');


   define('LANGID_FOOTERCOL','region20160624_0544061458');
  define('LANGID_FOOTERLINKS','region20160624_0543549215');
   define('LANGID_FOOTERLAST','region20150907_1044559577');
  
//LIUYAN
 define('LIUYAN_NAME','昵称');
  define('LIUYAN_EMAIL','电子邮箱');
   define('LIUYAN_TITLE','标题');
    define('LIUYAN_PHONE','手机');
   define('LIUYAN_CONTENT','内容');
 define('LIUYAN_SUBMIT','开始提交');
 define('LIUYAN_OK','留言成功');
 define('LIUYAN_REPEAT','请不要重复提交');
 
 define('LIUYAN_INPUT','请输入');
define('LIUYAN_ERROREMAIL','电子邮箱格式不对');
define('LIUYAN_ERROREPHONE','手机格式不对');
    //--------NEXTPREV
 define('NEXTPREV_NO','没有了');
 define('NEXTPREV_PREV','上一篇');
 define('NEXTPREV_NEXT','下一篇'); 
   //--------PAGER
  define('PAGER_FIRST','首页');
 define('PAGER_LAST','末页');
 define('PAGER_PREV','上一页'); 
 define('PAGER_NEXT','下一页');  
 //---------SEARCH
  define('SEARCH_BTN','搜索');
  define('SEARCH_KEYWORDS','关键字');
  define('SEARCH_ALERTKEYWORDS','请输入关键字');
  define('SEARCH_ALERTLONG','对不起，您输入的关键字太长');
  define('SEARCH_RESULT','搜索结果');
  define('SEARCH_NORESULT','对不起，没有找到相关内容');
?>
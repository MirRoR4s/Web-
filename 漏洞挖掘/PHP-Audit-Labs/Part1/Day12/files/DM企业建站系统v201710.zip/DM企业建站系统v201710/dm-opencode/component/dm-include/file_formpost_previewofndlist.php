<div class="container c">

<?php
/*
  欢迎使用DM企业建站系统，本系统由www.demososo.com开发。
*/
if(!defined('IN_DEMOSOSO')) {
  exit('this is wrong page,please back to homepage');
}
 if(dmlogin()){  
 echo '<title>预览</title>';

 require_once DISPLAYROOT.'a_meta.php'; 


$pidname = @htmlentities($_GET['pidname']);


//$pidname = 'ndlist20160712_1014264451';
block($pidname);

}
else {
  echo 'sorry,pls login...';
}

?>

</div>

<p style="height:100px;padding:50px;text-align:center">提示：个别预览可能不会有结果或不正常。这时以前台正式显示为准。</p>

<script>
$(function(){
	$('.blockregion').show();
});

</script>




 <?php 
 //以下 这是 mp4视频的js,css,如果不需要，可以删除
 get_assets_css_single(STAPATH.'app/libs/mediaelementplayer/mediaelementplayer.min.css'); 
 get_assets_js_single(STAPATH.'app/libs/mediaelementplayer/mediaelement-and-player.min.js');

?>
<script>
// using jQuery
$('video,audio').mediaelementplayer(/* Options */);
</script>
<?php 
// //以上 这是 mp4视频的js,css,如果不需要，可以删除
?>

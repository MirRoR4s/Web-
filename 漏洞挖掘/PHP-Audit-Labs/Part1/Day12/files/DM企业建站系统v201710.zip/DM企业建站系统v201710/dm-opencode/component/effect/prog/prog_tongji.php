<?php 

//请把这里的统计代码换成你自己的

?>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1256279252'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s95.cnzz.com/stat.php%3Fid%3D1256279252%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
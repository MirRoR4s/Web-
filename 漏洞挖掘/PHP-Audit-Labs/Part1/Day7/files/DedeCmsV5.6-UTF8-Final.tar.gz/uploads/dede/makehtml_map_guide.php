<?php
require_once(dirname(__FILE__)."/config.php");
include DedeInclude('templets/makehtml_map_guide.htm');
?>
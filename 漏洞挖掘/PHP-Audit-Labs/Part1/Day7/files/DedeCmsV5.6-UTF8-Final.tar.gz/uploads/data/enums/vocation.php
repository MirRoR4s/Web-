<?php
global $em_vocations;
$em_vocations = array();
$em_vocations[500] = '互联网';
$em_vocations[501] = '网站制作';
$em_vocations[502] = '虚心';
$em_vocations[503] = 'cms制作';
$em_vocations[1000] = '机械';
$em_vocations[1001] = '农业机械';
$em_vocations[1002] = '机床';
$em_vocations[1003] = '纺织设备和器材';
$em_vocations[1004] = '风机/排风设备';
?>